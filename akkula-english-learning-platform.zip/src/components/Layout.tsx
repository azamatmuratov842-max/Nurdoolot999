import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Sun, Moon, Globe, LogOut, User, Shield, ChevronDown, BookOpen, Brain, Trophy, MessageCircle, CreditCard, Info, Mail, Home, BarChart3, Award, Mic, Headphones, PenTool, GraduationCap } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

export function Navbar() {
  const { t, i18n } = useTranslation();
  const { state, logout, toggleTheme, isAdmin } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const languages = [
    { code: 'en', label: 'English', flag: '🇺🇸' },
    { code: 'ru', label: 'Русский', flag: '🇷🇺' },
    { code: 'ky', label: 'Кыргызча', flag: '🇰🇬' },
  ];

  const currentLang = languages.find(l => l.code === i18n.language) || languages[0];

  const navLinks = [
    { to: '/', label: t('nav.home'), icon: Home },
    { to: '/courses', label: t('nav.courses'), icon: BookOpen },
    { to: '/vocabulary', label: t('nav.vocabulary'), icon: Brain },
    { to: '/grammar', label: t('nav.grammar'), icon: GraduationCap },
    { to: '/practice', label: t('nav.practice'), icon: Mic },
    { to: '/pricing', label: t('nav.pricing'), icon: CreditCard },
    { to: '/leaderboard', label: t('nav.leaderboard'), icon: Trophy },
  ];

  const handleLogout = () => {
    logout();
    setUserMenuOpen(false);
    navigate('/');
  };

  return (
    <nav className="sticky top-0 z-50 glass border-b" style={{ borderColor: 'var(--border-color)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <div className="w-9 h-9 rounded-xl gradient-bg flex items-center justify-center text-white font-bold text-lg">A</div>
            <span className="font-bold text-lg gradient-text hidden sm:block">Akkula English</span>
          </Link>

          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map(link => (
              <Link
                key={link.to}
                to={link.to}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${location.pathname === link.to ? 'text-primary-600 bg-primary-50 dark:bg-primary-900/20' : 'hover:bg-gray-100 dark:hover:bg-gray-800'}`}
                style={{ color: location.pathname === link.to ? 'var(--gradient-start)' : 'var(--text-secondary)' }}
              >
                {link.label}
              </Link>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <button onClick={() => setLangOpen(!langOpen)} className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-sm hover:bg-gray-100 dark:hover:bg-gray-800 transition-all">
                <span className="text-base">{currentLang.flag}</span>
                <span className="hidden sm:inline text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>{currentLang.code.toUpperCase()}</span>
                <ChevronDown size={14} />
              </button>
              <AnimatePresence>
                {langOpen && (
                  <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                    className="absolute right-0 mt-2 w-44 rounded-xl shadow-xl glass py-2 z-50">
                    {languages.map(lang => (
                      <button key={lang.code} onClick={() => { i18n.changeLanguage(lang.code); setLangOpen(false); }}
                        className={`flex items-center gap-3 w-full px-4 py-2.5 text-sm transition-colors ${i18n.language === lang.code ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600' : 'hover:bg-gray-50 dark:hover:bg-gray-800'}`}>
                        <span className="text-lg">{lang.flag}</span>
                        <span>{lang.label}</span>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-all" title="Toggle theme">
              {state.theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {state.isAuthenticated ? (
              <div className="relative">
                <button onClick={() => setUserMenuOpen(!userMenuOpen)} className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-all">
                  <span className="text-xl">{state.user?.avatar}</span>
                  <span className="hidden sm:inline text-sm font-medium">{state.user?.name}</span>
                  <ChevronDown size={14} />
                </button>
                <AnimatePresence>
                  {userMenuOpen && (
                    <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                      className="absolute right-0 mt-2 w-52 rounded-xl shadow-xl glass py-2 z-50">
                      <div className="px-4 py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                        <p className="font-medium text-sm">{state.user?.name}</p>
                        <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{state.user?.email}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs px-2 py-0.5 rounded-full bg-primary-100 text-primary-700 dark:bg-primary-900/30 dark:text-primary-400">Lv.{state.user?.level}</span>
                          <span className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{state.user?.xp} XP</span>
                        </div>
                      </div>
                      <Link to="/dashboard" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-gray-50 dark:hover:bg-gray-800">
                        <BarChart3 size={16} /> {t('nav.dashboard')}
                      </Link>
                      <Link to="/profile" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-gray-50 dark:hover:bg-gray-800">
                        <User size={16} /> {t('nav.profile')}
                      </Link>
                      <Link to="/achievements" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-gray-50 dark:hover:bg-gray-800">
                        <Award size={16} /> {t('nav.achievements')}
                      </Link>
                      {isAdmin() && (
                        <Link to="/admin" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-gray-50 dark:hover:bg-gray-800 text-amber-600">
                          <Shield size={16} /> {t('nav.admin')}
                        </Link>
                      )}
                      <div className="border-t" style={{ borderColor: 'var(--border-color)' }}>
                        <button onClick={handleLogout} className="flex items-center gap-3 w-full px-4 py-2.5 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10">
                          <LogOut size={16} /> {t('nav.logout')}
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link to="/login" className="hidden sm:inline-flex px-4 py-2 text-sm font-medium rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-all">{t('nav.login')}</Link>
                <Link to="/register" className="btn-primary !py-2 !px-4 text-sm">{t('nav.register')}</Link>
              </div>
            )}

            <button onClick={() => setMenuOpen(!menuOpen)} className="lg:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="lg:hidden overflow-hidden border-t" style={{ borderColor: 'var(--border-color)' }}>
            <div className="px-4 py-3 space-y-1">
              {navLinks.map(link => (
                <Link key={link.to} to={link.to} onClick={() => setMenuOpen(false)}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${location.pathname === link.to ? 'bg-primary-50 dark:bg-primary-900/20' : 'hover:bg-gray-50 dark:hover:bg-gray-800'}`}
                  style={{ color: location.pathname === link.to ? 'var(--gradient-start)' : 'var(--text-primary)' }}>
                  <link.icon size={18} />
                  {link.label}
                </Link>
              ))}
              {!state.isAuthenticated && (
                <Link to="/login" onClick={() => setMenuOpen(false)} className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-800">
                  <User size={18} /> {t('nav.login')}
                </Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

export function Footer() {
  const { t } = useTranslation();

  return (
    <footer className="border-t py-12 px-4" style={{ borderColor: 'var(--border-color)', background: 'var(--bg-secondary)' }}>
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-xl gradient-bg flex items-center justify-center text-white font-bold text-lg">A</div>
              <span className="font-bold text-lg gradient-text">Akkula English</span>
            </div>
            <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>{t('footer.description')}</p>
            <div className="flex gap-3">
              <a href="#" className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-800 transition-all" style={{ color: 'var(--text-secondary)' }}>📘</a>
              <a href="#" className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-800 transition-all" style={{ color: 'var(--text-secondary)' }}>🐦</a>
              <a href="#" className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-800 transition-all" style={{ color: 'var(--text-secondary)' }}>📸</a>
            </div>
          </div>
          <div>
            <h3 className="font-semibold mb-4 text-sm">{t('footer.links')}</h3>
            <div className="space-y-2.5">
              {[{ to: '/courses', label: t('nav.courses') }, { to: '/vocabulary', label: t('nav.vocabulary') }, { to: '/grammar', label: t('nav.grammar') }, { to: '/leaderboard', label: t('nav.leaderboard') }, { to: '/pricing', label: t('nav.pricing') }].map(l => (
                <Link key={l.to} to={l.to} className="block text-sm hover:underline transition-all" style={{ color: 'var(--text-secondary)' }}>{l.label}</Link>
              ))}
            </div>
          </div>
          <div>
            <h3 className="font-semibold mb-4 text-sm">{t('footer.support')}</h3>
            <div className="space-y-2.5">
              <Link to="/contact" className="block text-sm hover:underline" style={{ color: 'var(--text-secondary)' }}>{t('nav.contact')}</Link>
              <Link to="/about" className="block text-sm hover:underline" style={{ color: 'var(--text-secondary)' }}>{t('nav.about')}</Link>
              <a href="#" className="block text-sm hover:underline" style={{ color: 'var(--text-secondary)' }}>{t('footer.faq')}</a>
              <a href="#" className="block text-sm hover:underline" style={{ color: 'var(--text-secondary)' }}>{t('footer.help')}</a>
            </div>
          </div>
          <div>
            <h3 className="font-semibold mb-4 text-sm">{t('footer.newsletter')}</h3>
            <p className="text-sm mb-3" style={{ color: 'var(--text-secondary)' }}>{t('footer.newsletter_desc')}</p>
            <div className="flex gap-2">
              <input type="email" placeholder={t('footer.email_placeholder')} className="input-field !py-2 text-sm flex-1" />
              <button className="btn-primary !py-2 !px-4 text-sm">{t('footer.subscribe')}</button>
            </div>
          </div>
        </div>
        <div className="border-t pt-6 flex flex-col sm:flex-row items-center justify-between gap-3" style={{ borderColor: 'var(--border-color)' }}>
          <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>© 2024-2026 Akkula English. {t('footer.rights')}</p>
          <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{t('footer.made_with')} ❤️ {t('footer.for_learners')}</p>
        </div>
      </div>
    </footer>
  );
}
