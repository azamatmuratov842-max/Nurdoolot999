import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Award, Lock, Star } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { achievementsList } from '../services/lessons';

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.08 } } };

export default function AchievementsPage() {
  const { t, i18n } = useTranslation();
  const { state } = useApp();
  const lang = i18n.language;
  const userAchievements = state.user?.achievements || [];

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <motion.div initial="hidden" animate="visible" variants={stagger}>
        <motion.div variants={fadeUp} className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t('achievements.title')}</h1>
          <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>{t('achievements.subtitle')}</p>
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full glass">
            <Award size={18} className="text-amber-500" />
            <span className="font-medium">{userAchievements.length} / {achievementsList.length} {t('achievements.unlocked')}</span>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {achievementsList.map(ach => {
            const isUnlocked = userAchievements.includes(ach.id);
            const name = lang === 'ru' ? ach.nameRu : lang === 'ky' ? ach.nameKy : ach.nameEn;
            const desc = lang === 'ru' ? ach.descRu : lang === 'ky' ? ach.descKy : ach.descEn;
            return (
              <motion.div key={ach.id} variants={fadeUp}
                className={`glass rounded-2xl p-6 card-hover relative overflow-hidden ${!isUnlocked ? 'opacity-60' : ''}`}>
                {isUnlocked && <div className="absolute top-0 right-0 w-20 h-20 rounded-full bg-amber-400/10 blur-2xl" />}
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-4xl">{ach.icon}</span>
                    {isUnlocked ? (
                      <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                        {t('achievements.unlocked')}
                      </span>
                    ) : (
                      <Lock size={18} style={{ color: 'var(--text-tertiary)' }} />
                    )}
                  </div>
                  <h3 className="font-semibold mb-1">{name}</h3>
                  <p className="text-sm mb-2" style={{ color: 'var(--text-secondary)' }}>{desc}</p>
                  <div className="flex items-center gap-1 text-xs text-amber-500">
                    <Star size={12} /> +{ach.xpReward} XP
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}
