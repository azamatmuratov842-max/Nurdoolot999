import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { Headphones, Mic, PenTool, Play, Square, Send, ArrowLeft, Volume2, CheckCircle, RotateCcw } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.1 } } };

const listeningExercises = [
  { id: 'le1', title: 'Daily Conversation', audio: '🗣️ "Good morning! How are you today?" "I\'m doing great, thanks for asking!"', question: 'How is the person feeling?', options: ['Sad', 'Great', 'Tired', 'Angry'], answer: 'Great', level: 1 },
  { id: 'le2', title: 'Weather Report', audio: '📻 "Today\'s weather will be sunny with a high of 75 degrees Fahrenheit. There\'s a slight chance of rain in the evening."', question: 'What is the weather forecast?', options: ['Rainy all day', 'Sunny with possible evening rain', 'Snowy', 'Cloudy'], answer: 'Sunny with possible evening rain', level: 2 },
  { id: 'le3', title: 'Restaurant Order', audio: '🍽️ "I\'d like to order the grilled salmon with a side of vegetables, please. And could I get a glass of water?"', question: 'What does the person want to drink?', options: ['Coffee', 'Juice', 'Water', 'Tea'], answer: 'Water', level: 2 },
];

const speakingPrompts = [
  { id: 'sp1', prompt: 'Introduce yourself in English. Say your name, where you are from, and what you like to do.', level: 1 },
  { id: 'sp2', prompt: 'Describe your favorite hobby. Why do you enjoy it? How often do you do it?', level: 2 },
  { id: 'sp3', prompt: 'Tell a short story about a memorable trip or experience you had.', level: 3 },
];

const writingPrompts = [
  { id: 'wp1', prompt: 'Write a short paragraph about your daily routine. Use Present Simple tense.', level: 1, example: 'I wake up at 7 AM every day. I eat breakfast and drink coffee. Then I go to work by bus. In the evening, I read a book before bed.' },
  { id: 'wp2', prompt: 'Write a letter to a friend inviting them to a party. Include the date, time, and location.', level: 2, example: 'Dear Alex,\nI hope you are doing well. I am having a party next Saturday at my house. It starts at 7 PM. I would love it if you could come!\nBest wishes,\n[Your name]' },
  { id: 'wp3', prompt: 'Write about a problem in your community and suggest a solution. Use at least 3 different tenses.', level: 3, example: 'Air pollution has become a serious issue in our city. The government has been trying to reduce emissions, but more needs to be done. If we plant more trees, we will improve air quality significantly.' },
];

export default function PracticePage() {
  const { t } = useTranslation();
  const { state, addXP } = useApp();
  const [activeTab, setActiveTab] = useState<'listening' | 'speaking' | 'writing'>('listening');
  const [currentExercise, setCurrentExercise] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [writingText, setWritingText] = useState('');
  const [showExample, setShowExample] = useState(false);

  const tabs = [
    { id: 'listening' as const, label: t('practice.listening'), icon: Headphones, color: 'from-blue-500 to-cyan-500' },
    { id: 'speaking' as const, label: t('practice.speaking'), icon: Mic, color: 'from-purple-500 to-violet-500' },
    { id: 'writing' as const, label: t('practice.writing'), icon: PenTool, color: 'from-amber-500 to-orange-500' },
  ];

  const handlePlayAudio = () => {
    setIsPlaying(true);
    setTimeout(() => setIsPlaying(false), 3000);
  };

  const handleCheckListening = () => {
    setShowResult(true);
    const exercise = listeningExercises[currentExercise];
    if (selectedAnswer === exercise.answer) addXP(20);
  };

  const handleToggleRecording = () => {
    setIsRecording(!isRecording);
    if (isRecording) addXP(15);
  };

  const handleSubmitWriting = () => {
    if (writingText.trim().length > 20) {
      addXP(25);
      setShowResult(true);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <motion.div initial="hidden" animate="visible" variants={stagger}>
        <motion.div variants={fadeUp} className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t('nav.practice')}</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Improve your English skills with interactive exercises</p>
        </motion.div>

        {/* Tabs */}
        <motion.div variants={fadeUp} className="flex justify-center gap-3 mb-10">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => { setActiveTab(tab.id); setCurrentExercise(0); setSelectedAnswer(''); setShowResult(false); setWritingText(''); setShowExample(false); }}
              className={`flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-medium transition-all ${activeTab === tab.id ? 'gradient-bg text-white shadow-lg' : 'glass hover:opacity-80'}`}>
              <tab.icon size={18} /> {tab.label}
            </button>
          ))}
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Listening */}
          {activeTab === 'listening' && (
            <motion.div key="listening" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="glass rounded-2xl p-6 md:p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center">
                    <Headphones className="text-white" size={24} />
                  </div>
                  <div>
                    <h2 className="font-semibold">{listeningExercises[currentExercise].title}</h2>
                    <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>Level {listeningExercises[currentExercise].level}</p>
                  </div>
                </div>

                {/* Audio Player */}
                <div className="rounded-xl p-6 mb-6 text-center" style={{ background: 'var(--bg-tertiary)' }}>
                  <button onClick={handlePlayAudio}
                    className={`w-16 h-16 mx-auto rounded-full gradient-bg flex items-center justify-center text-white mb-4 transition-transform ${isPlaying ? 'scale-110 animate-pulse' : ''}`}>
                    {isPlaying ? <Volume2 size={28} /> : <Play size={28} />}
                  </button>
                  {isPlaying && <p className="text-sm italic" style={{ color: 'var(--text-secondary)' }}>{listeningExercises[currentExercise].audio}</p>}
                  {!isPlaying && <p className="text-sm" style={{ color: 'var(--text-tertiary)' }}>{t('practice.play_audio')}</p>}
                </div>

                {/* Question */}
                <h3 className="font-medium mb-4">{listeningExercises[currentExercise].question}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                  {listeningExercises[currentExercise].options.map(opt => {
                    const isCorrect = showResult && opt === listeningExercises[currentExercise].answer;
                    const isWrong = showResult && selectedAnswer === opt && opt !== listeningExercises[currentExercise].answer;
                    const isSelected = selectedAnswer === opt;
                    return (
                      <button key={opt} onClick={() => !showResult && setSelectedAnswer(opt)}
                        disabled={showResult}
                        className={`p-4 rounded-xl text-left border-2 transition-all ${isCorrect ? 'border-green-500 bg-green-50 dark:bg-green-900/20' : isWrong ? 'border-red-500 bg-red-50 dark:bg-red-900/20' : isSelected ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'hover:border-gray-300'}`}
                        style={!isSelected && !isCorrect && !isWrong ? { borderColor: 'var(--border-color)' } : {}}>
                        {opt}
                      </button>
                    );
                  })}
                </div>

                {showResult && (
                  <div className={`p-4 rounded-xl mb-4 ${selectedAnswer === listeningExercises[currentExercise].answer ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20'}`}>
                    <p className="font-medium">{selectedAnswer === listeningExercises[currentExercise].answer ? '✅ Correct!' : '❌ Try again!'}</p>
                  </div>
                )}

                <div className="flex justify-between">
                  <button onClick={() => { setCurrentExercise(Math.max(0, currentExercise - 1)); setSelectedAnswer(''); setShowResult(false); setIsPlaying(false); }}
                    className="btn-secondary text-sm" disabled={currentExercise === 0}>
                    <ArrowLeft size={16} /> Previous
                  </button>
                  {!showResult ? (
                    <button onClick={handleCheckListening} className="btn-primary text-sm" disabled={!selectedAnswer}>
                      <CheckCircle size={16} /> Check Answer
                    </button>
                  ) : (
                    <button onClick={() => { setCurrentExercise((currentExercise + 1) % listeningExercises.length); setSelectedAnswer(''); setShowResult(false); setIsPlaying(false); }}
                      className="btn-primary text-sm">
                      Next <Play size={16} />
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {/* Speaking */}
          {activeTab === 'speaking' && (
            <motion.div key="speaking" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="glass rounded-2xl p-6 md:p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-purple-500 to-violet-500 flex items-center justify-center">
                    <Mic className="text-white" size={24} />
                  </div>
                  <div>
                    <h2 className="font-semibold">{t('practice.speaking')}</h2>
                    <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>Level {speakingPrompts[currentExercise % speakingPrompts.length].level}</p>
                  </div>
                </div>

                <div className="rounded-xl p-6 mb-8" style={{ background: 'var(--bg-tertiary)' }}>
                  <h3 className="font-medium mb-2">Speaking Prompt:</h3>
                  <p style={{ color: 'var(--text-secondary)' }}>{speakingPrompts[currentExercise % speakingPrompts.length].prompt}</p>
                </div>

                <div className="text-center mb-8">
                  <button onClick={handleToggleRecording}
                    className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto transition-all ${isRecording ? 'bg-red-500 text-white animate-pulse shadow-lg shadow-red-500/30' : 'gradient-bg text-white shadow-lg'}`}>
                    {isRecording ? <Square size={32} /> : <Mic size={32} />}
                  </button>
                  <p className="text-sm mt-3" style={{ color: 'var(--text-tertiary)' }}>
                    {isRecording ? 'Recording... Click to stop' : t('practice.record')}
                  </p>
                  {isRecording && (
                    <div className="flex justify-center gap-1 mt-2">
                      {[...Array(5)].map((_, i) => (
                        <div key={i} className="w-1 bg-red-500 rounded-full animate-pulse" style={{ height: `${12 + Math.random() * 20}px`, animationDelay: `${i * 100}ms` }} />
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex justify-between">
                  <button onClick={() => { setCurrentExercise(Math.max(0, currentExercise - 1)); setIsRecording(false); }}
                    className="btn-secondary text-sm" disabled={currentExercise === 0}>
                    <ArrowLeft size={16} /> Previous
                  </button>
                  <button onClick={() => { setCurrentExercise(currentExercise + 1); setIsRecording(false); }}
                    className="btn-primary text-sm">
                    Next Prompt <Play size={16} />
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* Writing */}
          {activeTab === 'writing' && (
            <motion.div key="writing" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <div className="glass rounded-2xl p-6 md:p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 flex items-center justify-center">
                    <PenTool className="text-white" size={24} />
                  </div>
                  <div>
                    <h2 className="font-semibold">{t('practice.writing')}</h2>
                    <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>Level {writingPrompts[currentExercise % writingPrompts.length].level}</p>
                  </div>
                </div>

                <div className="rounded-xl p-6 mb-6" style={{ background: 'var(--bg-tertiary)' }}>
                  <h3 className="font-medium mb-2">Writing Prompt:</h3>
                  <p style={{ color: 'var(--text-secondary)' }}>{writingPrompts[currentExercise % writingPrompts.length].prompt}</p>
                </div>

                <textarea value={writingText} onChange={e => setWritingText(e.target.value)}
                  placeholder="Start writing here..."
                  className="input-field h-48 resize-none mb-4" />

                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm" style={{ color: 'var(--text-tertiary)' }}>{t('practice.word_count')}: {writingText.trim() ? writingText.trim().split(/\s+/).length : 0}</span>
                  <button onClick={() => setShowExample(!showExample)} className="text-sm font-medium hover:underline" style={{ color: 'var(--gradient-start)' }}>
                    {showExample ? 'Hide Example' : 'Show Example'}
                  </button>
                </div>

                {showExample && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
                    className="rounded-xl p-4 mb-6 border border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20">
                    <p className="text-sm font-medium mb-2 text-green-700 dark:text-green-400">💡 Example:</p>
                    <p className="text-sm whitespace-pre-line" style={{ color: 'var(--text-secondary)' }}>{writingPrompts[currentExercise % writingPrompts.length].example}</p>
                  </motion.div>
                )}

                {showResult && (
                  <div className="rounded-xl p-4 mb-6 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
                    <p className="font-medium text-green-700 dark:text-green-400">✅ Great work! +25 XP</p>
                    <p className="text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>Keep practicing to improve your writing skills.</p>
                  </div>
                )}

                <div className="flex justify-between">
                  <button onClick={() => { setCurrentExercise(Math.max(0, currentExercise - 1)); setWritingText(''); setShowResult(false); setShowExample(false); }}
                    className="btn-secondary text-sm" disabled={currentExercise === 0}>
                    <ArrowLeft size={16} /> Previous
                  </button>
                  {!showResult ? (
                    <button onClick={handleSubmitWriting} className="btn-primary text-sm" disabled={writingText.trim().length < 10}>
                      <Send size={16} /> {t('practice.submit')}
                    </button>
                  ) : (
                    <button onClick={() => { setCurrentExercise(currentExercise + 1); setWritingText(''); setShowResult(false); setShowExample(false); }}
                      className="btn-primary text-sm">
                      Next <Play size={16} />
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
