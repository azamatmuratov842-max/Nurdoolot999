import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Shield, Users, BookOpen, BarChart3, Settings, Search, Plus, Edit3, Trash2, Ban, CheckCircle, XCircle, TrendingUp, DollarSign, Eye, UserCheck, ArrowLeft, ChevronRight } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { lessons as allLessons, courses } from '../services/lessons';

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.08 } } };

export default function AdminPage() {
  const { t } = useTranslation();
  const { state, isAdmin, getAllUsers, banUser, unbanUser } = useApp();
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddLesson, setShowAddLesson] = useState(false);
  const [newLesson, setNewLesson] = useState({ title: '', type: 'grammar', level: '1', content: '', xp: '50' });

  if (!state.isAuthenticated || !isAdmin()) return <Navigate to="/" replace />;

  const users = getAllUsers();
  const filteredUsers = users.filter(u => u.name.toLowerCase().includes(searchQuery.toLowerCase()) || u.email.toLowerCase().includes(searchQuery.toLowerCase()));

  const tabs = [
    { id: 'overview', label: t('admin.overview'), icon: BarChart3 },
    { id: 'users', label: t('admin.users'), icon: Users },
    { id: 'lessons', label: t('admin.lessons'), icon: BookOpen },
    { id: 'analytics', label: t('admin.analytics'), icon: TrendingUp },
    { id: 'settings', label: t('admin.settings'), icon: Settings },
  ];

  const stats = [
    { label: t('admin.total_users'), value: users.length, icon: Users, color: 'from-blue-500 to-cyan-500', change: '+12%' },
    { label: t('admin.active_users'), value: users.filter(u => !u.banned).length, icon: UserCheck, color: 'from-green-500 to-emerald-500', change: '+8%' },
    { label: t('admin.total_lessons'), value: allLessons.length, icon: BookOpen, color: 'from-purple-500 to-violet-500', change: '+3' },
    { label: t('admin.total_revenue'), value: '247,500 KGS', icon: DollarSign, color: 'from-amber-500 to-orange-500', change: '+23%' },
  ];

  const handleAddLesson = () => {
    setShowAddLesson(false);
    setNewLesson({ title: '', type: 'grammar', level: '1', content: '', xp: '50' });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <motion.div initial="hidden" animate="visible" variants={stagger}>
        {/* Header */}
        <motion.div variants={fadeUp} className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 flex items-center justify-center">
            <Shield className="text-white" size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{t('admin.title')}</h1>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>Welcome, Admin</p>
          </div>
        </motion.div>

        {/* Tabs */}
        <motion.div variants={fadeUp} className="flex gap-2 mb-8 overflow-x-auto scrollbar-hide pb-2">
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${activeTab === tab.id ? 'gradient-bg text-white' : 'glass hover:opacity-80'}`}>
              <tab.icon size={16} /> {tab.label}
            </button>
          ))}
        </motion.div>

        {/* Overview */}
        {activeTab === 'overview' && (
          <motion.div variants={stagger} initial="hidden" animate="visible">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {stats.map((stat, i) => (
                <motion.div key={i} variants={fadeUp} className="glass rounded-xl p-5 card-hover">
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-r ${stat.color} flex items-center justify-center`}>
                      <stat.icon className="text-white" size={18} />
                    </div>
                    <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">{stat.change}</span>
                  </div>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{stat.label}</div>
                </motion.div>
              ))}
            </div>

            {/* Chart placeholder */}
            <motion.div variants={fadeUp} className="glass rounded-xl p-6 mb-8">
              <h3 className="font-semibold mb-4">User Growth</h3>
              <div className="flex items-end gap-2 h-48">
                {[35, 45, 55, 40, 60, 75, 70, 85, 90, 95, 88, 100].map((v, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <div className="w-full rounded-t-lg gradient-bg transition-all" style={{ height: `${v}%` }} />
                    <span className="text-[10px]" style={{ color: 'var(--text-tertiary)' }}>{['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][i]}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Recent Users */}
            <motion.div variants={fadeUp} className="glass rounded-xl p-6">
              <h3 className="font-semibold mb-4">Recent Users</h3>
              <div className="space-y-3">
                {users.slice(0, 5).map(u => (
                  <div key={u.id} className="flex items-center gap-3 p-3 rounded-lg" style={{ background: 'var(--bg-tertiary)' }}>
                    <span className="text-2xl">{u.avatar}</span>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{u.name}</p>
                      <p className="text-xs truncate" style={{ color: 'var(--text-tertiary)' }}>{u.email}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${u.banned ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'} dark:bg-opacity-20`}>
                      {u.banned ? 'Banned' : 'Active'}
                    </span>
                  </div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Users */}
        {activeTab === 'users' && (
          <motion.div variants={stagger} initial="hidden" animate="visible">
            <motion.div variants={fadeUp} className="flex items-center gap-3 mb-6">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
                  placeholder={t('admin.search')} className="input-field !pl-10" />
              </div>
            </motion.div>
            <motion.div variants={fadeUp} className="glass rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ background: 'var(--bg-tertiary)' }}>
                      <th className="text-left px-4 py-3 font-medium">User</th>
                      <th className="text-left px-4 py-3 font-medium hidden md:table-cell">Email</th>
                      <th className="text-left px-4 py-3 font-medium">{t('admin.role')}</th>
                      <th className="text-left px-4 py-3 font-medium">{t('admin.status')}</th>
                      <th className="text-left px-4 py-3 font-medium hidden sm:table-cell">Level</th>
                      <th className="text-left px-4 py-3 font-medium hidden sm:table-cell">XP</th>
                      <th className="text-right px-4 py-3 font-medium">{t('admin.actions')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map(u => (
                      <tr key={u.id} className="border-t" style={{ borderColor: 'var(--border-color)' }}>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <span className="text-xl">{u.avatar}</span>
                            <span className="font-medium">{u.name}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 hidden md:table-cell" style={{ color: 'var(--text-secondary)' }}>{u.email}</td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2 py-1 rounded-full ${u.role === 'admin' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' : 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300'}`}>
                            {u.role}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2 py-1 rounded-full ${u.banned ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' : 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'}`}>
                            {u.banned ? 'Banned' : 'Active'}
                          </span>
                        </td>
                        <td className="px-4 py-3 hidden sm:table-cell">{u.level}</td>
                        <td className="px-4 py-3 hidden sm:table-cell">{u.xp}</td>
                        <td className="px-4 py-3 text-right">
                          {u.role !== 'admin' && (
                            u.banned ? (
                              <button onClick={() => unbanUser(u.id)} className="text-xs px-3 py-1.5 rounded-lg bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-400 transition-colors">
                                <CheckCircle size={14} className="inline mr-1" />{t('admin.unban_user')}
                              </button>
                            ) : (
                              <button onClick={() => banUser(u.id)} className="text-xs px-3 py-1.5 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-400 transition-colors">
                                <Ban size={14} className="inline mr-1" />{t('admin.ban_user')}
                              </button>
                            )
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Lessons */}
        {activeTab === 'lessons' && (
          <motion.div variants={stagger} initial="hidden" animate="visible">
            <motion.div variants={fadeUp} className="flex items-center justify-between mb-6">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                <input type="text" placeholder={t('admin.search')} className="input-field !pl-10" />
              </div>
              <button onClick={() => setShowAddLesson(true)} className="btn-primary text-sm">
                <Plus size={16} /> {t('admin.add_lesson')}
              </button>
            </motion.div>

            {showAddLesson && (
              <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-xl p-6 mb-6">
                <h3 className="font-semibold mb-4">{t('admin.add_lesson')}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <input type="text" value={newLesson.title} onChange={e => setNewLesson({ ...newLesson, title: e.target.value })}
                    placeholder="Lesson Title" className="input-field" />
                  <select value={newLesson.type} onChange={e => setNewLesson({ ...newLesson, type: e.target.value })} className="input-field">
                    <option value="grammar">Grammar</option>
                    <option value="vocabulary">Vocabulary</option>
                    <option value="reading">Reading</option>
                    <option value="listening">Listening</option>
                    <option value="speaking">Speaking</option>
                    <option value="writing">Writing</option>
                  </select>
                  <select value={newLesson.level} onChange={e => setNewLesson({ ...newLesson, level: e.target.value })} className="input-field">
                    {[1,2,3,4,5,6].map(l => <option key={l} value={l}>Level {l}</option>)}
                  </select>
                  <input type="number" value={newLesson.xp} onChange={e => setNewLesson({ ...newLesson, xp: e.target.value })} placeholder="XP Reward" className="input-field" />
                </div>
                <textarea value={newLesson.content} onChange={e => setNewLesson({ ...newLesson, content: e.target.value })}
                  placeholder="Lesson content..." className="input-field h-32 resize-none mb-4" />
                <div className="flex gap-3">
                  <button onClick={handleAddLesson} className="btn-primary text-sm">{t('admin.save')}</button>
                  <button onClick={() => setShowAddLesson(false)} className="btn-secondary text-sm">{t('admin.cancel')}</button>
                </div>
              </motion.div>
            )}

            <motion.div variants={fadeUp} className="space-y-3">
              {allLessons.map(lesson => (
                <div key={lesson.id} className="glass rounded-xl p-4 flex items-center gap-4 card-hover">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                    <BookOpen size={18} className="text-blue-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm">{lesson.title}</h4>
                    <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{lesson.type} • Level {lesson.level} • {lesson.xp} XP</p>
                  </div>
                  <div className="flex gap-2">
                    <button className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-blue-500"><Edit3 size={16} /></button>
                    <button className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 text-red-500"><Trash2 size={16} /></button>
                  </div>
                </div>
              ))}
            </motion.div>
          </motion.div>
        )}

        {/* Analytics */}
        {activeTab === 'analytics' && (
          <motion.div variants={stagger} initial="hidden" animate="visible">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <motion.div variants={fadeUp} className="glass rounded-xl p-6">
                <h3 className="font-semibold mb-4">Lessons by Type</h3>
                <div className="space-y-3">
                  {['grammar', 'vocabulary', 'reading', 'listening', 'speaking', 'writing'].map(type => {
                    const count = allLessons.filter(l => l.type === type).length;
                    const pct = Math.round((count / allLessons.length) * 100);
                    return (
                      <div key={type}>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="capitalize">{type}</span>
                          <span>{count} ({pct}%)</span>
                        </div>
                        <div className="progress-bar">
                          <div className="progress-fill" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
              <motion.div variants={fadeUp} className="glass rounded-xl p-6">
                <h3 className="font-semibold mb-4">Level Distribution</h3>
                <div className="space-y-3">
                  {[1,2,3,4,5,6].map(level => {
                    const count = users.filter(u => u.level === level).length;
                    const pct = users.length > 0 ? Math.round((count / users.length) * 100) : 0;
                    return (
                      <div key={level}>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Level {level}</span>
                          <span>{count} users ({pct}%)</span>
                        </div>
                        <div className="progress-bar">
                          <div className="progress-fill" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </motion.div>
            </div>
          </motion.div>
        )}

        {/* Settings */}
        {activeTab === 'settings' && (
          <motion.div variants={stagger} initial="hidden" animate="visible">
            <motion.div variants={fadeUp} className="glass rounded-xl p-6 max-w-2xl">
              <h3 className="font-semibold mb-6">Site Settings</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Site Name</label>
                  <input type="text" defaultValue="Akkula English" className="input-field" />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Premium Price (KGS/month)</label>
                  <input type="number" defaultValue="499" className="input-field" />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Default Language</label>
                  <select className="input-field">
                    <option value="en">English</option>
                    <option value="ru">Русский</option>
                    <option value="ky">Кыргызча</option>
                  </select>
                </div>
                <div className="flex items-center justify-between p-4 rounded-xl" style={{ background: 'var(--bg-tertiary)' }}>
                  <div>
                    <p className="font-medium text-sm">Maintenance Mode</p>
                    <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>Temporarily disable the site</p>
                  </div>
                  <button className="w-12 h-6 rounded-full bg-gray-300 dark:bg-gray-600 relative transition-colors">
                    <div className="w-5 h-5 rounded-full bg-white shadow absolute top-0.5 left-0.5 transition-transform" />
                  </button>
                </div>
                <button className="btn-primary text-sm">{t('admin.save')}</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
