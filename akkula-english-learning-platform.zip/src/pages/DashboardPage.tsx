import { Link, Navigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { BookOpen, Flame, Zap, Trophy, Clock, Target, ArrowRight, TrendingUp, Calendar, Award, Star, Play, CheckCircle } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { lessons, courses, achievementsList } from '../services/lessons';

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.08 } } };

const levelNames: Record<string, Record<string, string>> = {
  en: { 1: 'Beginner', 2: 'Elementary', 3: 'Pre-Intermediate', 4: 'Intermediate', 5: 'Upper Intermediate', 6: 'Advanced' },
  ru: { 1: 'Начинающий', 2: 'Элементарный', 3: 'Ниже среднего', 4: 'Средний', 5: 'Выше среднего', 6: 'Продвинутый' },
  ky: { 1: 'Баштапкы', 2: 'Элементардык', 3: 'Ортодон тѳмѳн', 4: 'Орто', 5: 'Ортодон жогору', 6: 'Ѳнүккѳн' },
};

export default function DashboardPage() {
  const { t, i18n } = useTranslation();
  const { state } = useApp();
  const lang = i18n.language;

  if (!state.isAuthenticated) return <Navigate to="/login" replace />;
  const user = state.user!;

  const userLevel = user.level;
  const xpForNext = userLevel * 500;
  const progressPct = Math.min(100, (user.xp % 500) / 5 * 1);

  const nextLessons = lessons.filter(l => !user.lessonsCompleted.includes(l.id) && l.level <= userLevel).slice(0, 4);
  const recentCourses = courses.filter(c => c.level <= userLevel).slice(0, 3);
  const userAchievements = achievementsList.filter(a => user.achievements.includes(a.id));

  const weekDays = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
  const weekData = weekDays.map(() => Math.floor(Math.random() * 60 + 20));

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <motion.div initial="hidden" animate="visible" variants={stagger}>
        {/* Welcome */}
        <motion.div variants={fadeUp} className="glass rounded-2xl p-6 md:p-8 mb-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-blue-500/10 blur-3xl -translate-y-1/2 translate-x-1/2" />
          <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-1">{t('dashboard.welcome', { name: user.name })}</h1>
              <p style={{ color: 'var(--text-secondary)' }}>{levelNames[lang]?.[userLevel] || levelNames.en[userLevel]} • {t('dashboard.level')} {userLevel}</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="flex items-center gap-1.5 text-amber-500"><Flame size={20} /><span className="text-2xl font-bold">{user.streak}</span></div>
                <span className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{t('dashboard.streak')}</span>
              </div>
              <div className="text-center">
                <div className="flex items-center gap-1.5" style={{ color: 'var(--gradient-start)' }}><Zap size={20} /><span className="text-2xl font-bold">{user.xp}</span></div>
                <span className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{t('dashboard.xp')}</span>
              </div>
            </div>
          </div>
          <div className="mt-6 relative z-10">
            <div className="flex justify-between text-sm mb-2">
              <span>{t('dashboard.level')} {userLevel}</span>
              <span>{t('dashboard.level')} {Math.min(6, userLevel + 1)}</span>
            </div>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: `${progressPct}%` }} />
            </div>
            <p className="text-xs mt-1" style={{ color: 'var(--text-tertiary)' }}>{user.xp % 500} / 500 XP to next level</p>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div variants={fadeUp} className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { icon: BookOpen, label: t('dashboard.lessons_done'), value: user.lessonsCompleted.length, color: 'text-blue-500' },
            { icon: Flame, label: t('dashboard.streak'), value: `${user.streak} days`, color: 'text-orange-500' },
            { icon: Trophy, label: t('dashboard.rank'), value: `#${Math.floor(Math.random() * 100 + 1)}`, color: 'text-amber-500' },
            { icon: Award, label: t('dashboard.achievements'), value: `${userAchievements.length}/${achievementsList.length}`, color: 'text-purple-500' },
          ].map((stat, i) => (
            <div key={i} className="glass rounded-xl p-5 card-hover">
              <stat.icon className={`${stat.color} mb-2`} size={22} />
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{stat.label}</div>
            </div>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Continue Learning */}
          <motion.div variants={fadeUp} className="lg:col-span-2">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">{t('dashboard.continue_learning')}</h2>
              <Link to="/courses" className="text-sm font-medium hover:underline" style={{ color: 'var(--gradient-start)' }}>{t('common.view_all')}</Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {nextLessons.map((lesson, i) => {
                const typeColors: Record<string, string> = {
                  grammar: 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400',
                  vocabulary: 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400',
                  reading: 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400',
                  listening: 'bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400',
                  speaking: 'bg-rose-100 text-rose-600 dark:bg-rose-900/30 dark:text-rose-400',
                  writing: 'bg-cyan-100 text-cyan-600 dark:bg-cyan-900/30 dark:text-cyan-400',
                  quiz: 'bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400',
                };
                return (
                  <Link key={lesson.id} to={`/lesson/${lesson.id}`}
                    className="glass rounded-xl p-5 card-hover flex items-start gap-4">
                    <div className={`w-10 h-10 rounded-lg ${typeColors[lesson.type] || typeColors.grammar} flex items-center justify-center shrink-0`}>
                      <BookOpen size={18} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-sm truncate">{lang === 'ru' ? lesson.titleRu : lang === 'ky' ? lesson.titleKy : lesson.title}</h3>
                      <p className="text-xs mt-1 truncate" style={{ color: 'var(--text-tertiary)' }}>{lesson.type} • {lesson.duration} min • {lesson.xp} XP</p>
                      {lesson.isPremium && <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 mt-2 inline-block">Premium</span>}
                    </div>
                    <Play size={16} className="shrink-0 mt-1" style={{ color: 'var(--text-tertiary)' }} />
                  </Link>
                );
              })}
            </div>
          </motion.div>

          {/* Weekly Progress */}
          <motion.div variants={fadeUp}>
            <h2 className="text-lg font-semibold mb-4">{t('dashboard.weekly_progress')}</h2>
            <div className="glass rounded-xl p-5">
              <div className="flex items-end justify-between h-40 gap-2 mb-4">
                {weekData.map((val, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <div className="w-full rounded-t-lg gradient-bg transition-all" style={{ height: `${val}%` }} />
                    <span className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{weekDays[i]}</span>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between text-sm">
                <span style={{ color: 'var(--text-secondary)' }}>{t('dashboard.minutes_today')}</span>
                <span className="font-semibold">{weekData[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1]} min</span>
              </div>
            </div>

            {/* Daily Goal */}
            <div className="glass rounded-xl p-5 mt-4">
              <div className="flex items-center gap-2 mb-3">
                <Target size={18} style={{ color: 'var(--gradient-start)' }} />
                <span className="font-medium text-sm">{t('dashboard.daily_goal')}</span>
              </div>
              <div className="progress-bar mb-2">
                <div className="progress-fill" style={{ width: '65%' }} />
              </div>
              <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>3 of 5 lessons completed today</p>
            </div>

            {/* Achievements */}
            <div className="glass rounded-xl p-5 mt-4">
              <div className="flex items-center justify-between mb-3">
                <span className="font-medium text-sm">{t('dashboard.achievements')}</span>
                <Link to="/achievements" className="text-xs" style={{ color: 'var(--gradient-start)' }}>{t('common.view_all')}</Link>
              </div>
              <div className="flex gap-2 flex-wrap">
                {userAchievements.length > 0 ? userAchievements.map(a => (
                  <div key={a.id} className="w-10 h-10 rounded-lg bg-amber-100 dark:bg-amber-900/20 flex items-center justify-center text-lg" title={a.id}>{a.icon}</div>
                )) : (
                  <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>Complete lessons to earn achievements!</p>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
