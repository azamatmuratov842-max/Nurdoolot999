import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { BookOpen, Brain, TrendingUp, Users, GraduationCap, Zap, ArrowRight, Star, Play, CheckCircle, Globe, Award, Headphones } from 'lucide-react';
import { courses } from '../services/lessons';

const fadeUp = { hidden: { opacity: 0, y: 30 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.1 } } };

export default function HomePage() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language;

  const stats = [
    { value: '50K+', label: t('hero.students'), icon: Users },
    { value: '500+', label: t('hero.lessons'), icon: BookOpen },
    { value: '4.9', label: t('hero.rating'), icon: Star },
    { value: '120+', label: t('hero.countries'), icon: Globe },
  ];

  const features = [
    { title: t('features.ai_title'), desc: t('features.ai_desc'), icon: Brain, color: 'bg-violet-100 text-violet-600 dark:bg-violet-900/30 dark:text-violet-400' },
    { title: t('features.lessons_title'), desc: t('features.lessons_desc'), icon: BookOpen, color: 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400' },
    { title: t('features.progress_title'), desc: t('features.progress_desc'), icon: TrendingUp, color: 'bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400' },
    { title: t('features.community_title'), desc: t('features.community_desc'), icon: Users, color: 'bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400' },
    { title: t('features.grammar_title'), desc: t('features.grammar_desc'), icon: GraduationCap, color: 'bg-rose-100 text-rose-600 dark:bg-rose-900/30 dark:text-rose-400' },
    { title: t('features.vocab_title'), desc: t('features.vocab_desc'), icon: Zap, color: 'bg-cyan-100 text-cyan-600 dark:bg-cyan-900/30 dark:text-cyan-400' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden py-20 md:py-32 px-4">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-20 left-10 w-72 h-72 rounded-full bg-blue-400/20 blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-purple-400/20 blur-3xl" />
        </div>
        <motion.div className="max-w-6xl mx-auto text-center relative z-10" initial="hidden" animate="visible" variants={stagger}>
          <motion.div variants={fadeUp} className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-6 border"
            style={{ borderColor: 'var(--border-color)', background: 'var(--bg-card)' }}>
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span style={{ color: 'var(--text-secondary)' }}>Trusted by 50,000+ learners worldwide</span>
          </motion.div>
          <motion.h1 variants={fadeUp} className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
            {t('hero.title')}{' '}
            <span className="gradient-text">{t('hero.brand')}</span>
          </motion.h1>
          <motion.p variants={fadeUp} className="text-lg md:text-xl max-w-3xl mx-auto mb-10 leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
            {t('hero.subtitle')}
          </motion.p>
          <motion.div variants={fadeUp} className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <Link to="/register" className="btn-primary text-lg !py-4 !px-8 w-full sm:w-auto">
              <Play size={20} /> {t('hero.cta')}
            </Link>
            <Link to="/courses" className="btn-secondary text-lg !py-4 !px-8 w-full sm:w-auto">
              {t('hero.cta2')} <ArrowRight size={20} />
            </Link>
          </motion.div>
          <motion.div variants={fadeUp} className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {stats.map((stat, i) => (
              <div key={i} className="glass rounded-2xl p-6 text-center card-hover">
                <stat.icon className="mx-auto mb-2" style={{ color: 'var(--gradient-start)' }} size={24} />
                <div className="text-2xl md:text-3xl font-bold gradient-text">{stat.value}</div>
                <div className="text-sm mt-1" style={{ color: 'var(--text-secondary)' }}>{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </motion.div>
      </section>

      {/* Features */}
      <section className="py-20 px-4" style={{ background: 'var(--bg-secondary)' }}>
        <div className="max-w-6xl mx-auto">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-16">
            <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold mb-4">{t('features.title')}</motion.h2>
            <motion.p variants={fadeUp} className="text-lg max-w-2xl mx-auto" style={{ color: 'var(--text-secondary)' }}>{t('features.subtitle')}</motion.p>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <motion.div key={i} variants={fadeUp} className="glass rounded-2xl p-6 card-hover">
                <div className={`w-12 h-12 rounded-xl ${f.color} flex items-center justify-center mb-4`}>
                  <f.icon size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{f.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Courses Preview */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-12">
            <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold mb-4">{t('courses.title')}</motion.h2>
            <motion.p variants={fadeUp} className="text-lg" style={{ color: 'var(--text-secondary)' }}>{t('courses.subtitle')}</motion.p>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.slice(0, 3).map((course) => (
              <motion.div key={course.id} variants={fadeUp} className="glass rounded-2xl overflow-hidden card-hover">
                <div className={`h-2 bg-gradient-to-r ${course.color}`} />
                <div className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-3xl">{course.icon}</span>
                    <div>
                      <h3 className="font-semibold">{lang === 'ru' ? course.titleRu : lang === 'ky' ? course.titleKy : course.titleEn}</h3>
                      <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}>
                        {t('courses.level', { level: course.level })}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>
                    {lang === 'ru' ? course.descriptionRu : lang === 'ky' ? course.descriptionKy : course.descriptionEn}
                  </p>
                  <div className="flex items-center justify-between text-xs mb-4" style={{ color: 'var(--text-tertiary)' }}>
                    <span>📚 {t('courses.lessons_count', { count: course.lessons })}</span>
                    <span>👥 {t('courses.students_count', { count: course.students })}</span>
                  </div>
                  <Link to="/courses" className="btn-primary w-full text-sm">
                    {t('courses.start_course')} <ArrowRight size={16} />
                  </Link>
                </div>
              </motion.div>
            ))}
          </motion.div>
          <div className="text-center mt-10">
            <Link to="/courses" className="btn-secondary">
              {t('common.view_all')} <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 px-4" style={{ background: 'var(--bg-secondary)' }}>
        <div className="max-w-6xl mx-auto">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-16">
            <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold mb-4">How It Works</motion.h2>
            <motion.p variants={fadeUp} className="text-lg" style={{ color: 'var(--text-secondary)' }}>Start learning in 3 simple steps</motion.p>
          </motion.div>
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'Create Account', desc: 'Sign up for free and set your learning goals', icon: Users, color: 'from-blue-500 to-cyan-500' },
              { step: '02', title: 'Choose Course', desc: 'Select from our range of expert-crafted courses', icon: BookOpen, color: 'from-purple-500 to-pink-500' },
              { step: '03', title: 'Learn & Practice', desc: 'Complete lessons, track progress, earn achievements', icon: Award, color: 'from-amber-500 to-orange-500' },
            ].map((item, i) => (
              <motion.div key={i} variants={fadeUp} className="text-center relative">
                <div className={`w-16 h-16 mx-auto rounded-2xl bg-gradient-to-r ${item.color} text-white flex items-center justify-center mb-4 shadow-lg`}>
                  <item.icon size={28} />
                </div>
                <span className="text-5xl font-bold opacity-10 absolute top-0 left-1/2 -translate-x-1/2">{item.step}</span>
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{item.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="max-w-4xl mx-auto text-center">
          <motion.div variants={fadeUp} className="glass rounded-3xl p-12 md:p-16 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-blue-500 blur-3xl" />
              <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full bg-purple-500 blur-3xl" />
            </div>
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Start Your English Journey?</h2>
              <p className="text-lg mb-8" style={{ color: 'var(--text-secondary)' }}>Join thousands of learners mastering English with Akkula English</p>
              <Link to="/register" className="btn-primary text-lg !py-4 !px-10">
                <CheckCircle size={20} /> Get Started Free
              </Link>
            </div>
          </motion.div>
        </motion.div>
      </section>
    </div>
  );
}
