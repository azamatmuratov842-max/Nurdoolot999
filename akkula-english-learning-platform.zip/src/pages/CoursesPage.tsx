import { Link, Navigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { BookOpen, Users, Lock, ArrowRight, CheckCircle, Crown, Play } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { courses, lessons } from '../services/lessons';

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.1 } } };

export default function CoursesPage() {
  const { t, i18n } = useTranslation();
  const { state } = useApp();
  const lang = i18n.language;

  const userLevel = state.user?.level || 1;

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <motion.div initial="hidden" animate="visible" variants={stagger}>
        <motion.div variants={fadeUp} className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t('courses.title')}</h1>
          <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>{t('courses.subtitle')}</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => {
            const isLocked = course.level > userLevel + 1;
            const isCurrent = course.level === userLevel || course.level === userLevel + 1;
            const isCompleted = course.level < userLevel;
            const courseLessons = lessons.filter(l => l.level === course.level);
            const completedCount = courseLessons.filter(l => state.user?.lessonsCompleted.includes(l.id)).length;
            const progress = courseLessons.length > 0 ? Math.round((completedCount / courseLessons.length) * 100) : 0;

            return (
              <motion.div key={course.id} variants={fadeUp}>
                <div className={`glass rounded-2xl overflow-hidden card-hover relative ${isLocked ? 'opacity-60' : ''}`}>
                  <div className={`h-2 bg-gradient-to-r ${course.color}`} />
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <span className="text-4xl">{course.icon}</span>
                        <div>
                          <h3 className="font-semibold text-lg">{lang === 'ru' ? course.titleRu : lang === 'ky' ? course.titleKy : course.titleEn}</h3>
                          <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}>
                            {t('courses.level', { level: course.level })}
                          </span>
                        </div>
                      </div>
                      {isCompleted && <CheckCircle className="text-green-500" size={24} />}
                      {isLocked && <Lock className="text-gray-400" size={24} />}
                      {course.level >= 5 && <Crown className="text-amber-500" size={20} />}
                    </div>

                    <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>
                      {lang === 'ru' ? course.descriptionRu : lang === 'ky' ? course.descriptionKy : course.descriptionEn}
                    </p>

                    <div className="flex items-center gap-4 text-xs mb-4" style={{ color: 'var(--text-tertiary)' }}>
                      <span className="flex items-center gap-1"><BookOpen size={14} />{t('courses.lessons_count', { count: course.lessons })}</span>
                      <span className="flex items-center gap-1"><Users size={14} />{t('courses.students_count', { count: course.students })}</span>
                    </div>

                    {progress > 0 && (
                      <div className="mb-4">
                        <div className="flex justify-between text-xs mb-1">
                          <span>{progress}%</span>
                          <span>{completedCount}/{courseLessons.length}</span>
                        </div>
                        <div className="progress-bar">
                          <div className="progress-fill" style={{ width: `${progress}%` }} />
                        </div>
                      </div>
                    )}

                    {isLocked ? (
                      <div className="btn-secondary w-full text-sm justify-center opacity-60 cursor-not-allowed">
                        <Lock size={16} /> {t('courses.locked')}
                      </div>
                    ) : course.level >= 5 && !state.user?.isPremium ? (
                      <Link to="/pricing" className="btn-secondary w-full text-sm justify-center">
                        <Crown size={16} className="text-amber-500" /> {t('courses.premium_only')}
                      </Link>
                    ) : (
                      <Link to={`/lesson/${courseLessons[0]?.id || 'l1'}`} className="btn-primary w-full text-sm">
                        {isCompleted ? <><CheckCircle size={16} /> {t('courses.completed')}</> :
                          progress > 0 ? <><Play size={16} /> {t('courses.continue_course')}</> :
                            <><Play size={16} /> {t('courses.start_course')}</>}
                        <ArrowRight size={16} />
                      </Link>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}
