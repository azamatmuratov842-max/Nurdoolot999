import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { User, Mail, Globe, Moon, Sun, Bell, Volume2, Save, CheckCircle, Lock, Trash2, Camera } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.08 } } };

export default function ProfilePage() {
  const { t, i18n } = useTranslation();
  const { state, updateProfile, toggleTheme } = useApp();
  const [name, setName] = useState(state.user?.name || '');
  const [saved, setSaved] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [sound, setSound] = useState(true);

  if (!state.isAuthenticated) return <Navigate to="/login" replace />;

  const handleSave = () => {
    updateProfile({ name });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const avatarOptions = ['🦊', '🐱', '🐶', '🐼', '🦁', '🐸', '🦋', '🌟', '🎯', '🚀', '💎', '🌈', '🦄', '🐻', '🐨', '🐯'];

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <motion.div initial="hidden" animate="visible" variants={stagger}>
        <motion.div variants={fadeUp} className="mb-8">
          <h1 className="text-3xl font-bold mb-2">{t('profile.title')}</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Manage your account settings</p>
        </motion.div>

        {/* Avatar Section */}
        <motion.div variants={fadeUp} className="glass rounded-2xl p-6 mb-6">
          <h2 className="font-semibold mb-4">{t('profile.avatar')}</h2>
          <div className="flex items-center gap-4 mb-4">
            <div className="w-20 h-20 rounded-2xl gradient-bg flex items-center justify-center text-4xl">
              {state.user?.avatar}
            </div>
            <div>
              <p className="font-semibold text-lg">{state.user?.name}</p>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{state.user?.email}</p>
              <p className="text-xs mt-1 px-2 py-0.5 rounded-full inline-block bg-primary-100 text-primary-700 dark:bg-primary-900/30 dark:text-primary-400">
                Level {state.user?.level} • {state.user?.xp} XP
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {avatarOptions.map(av => (
              <button key={av} onClick={() => updateProfile({ avatar: av })}
                className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl transition-all hover:scale-110 ${state.user?.avatar === av ? 'ring-2 ring-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'hover:bg-gray-100 dark:hover:bg-gray-800'}`}>
                {av}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Personal Info */}
        <motion.div variants={fadeUp} className="glass rounded-2xl p-6 mb-6">
          <h2 className="font-semibold mb-4">Personal Information</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1 block">{t('profile.name')}</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                <input type="text" value={name} onChange={e => setName(e.target.value)} className="input-field !pl-10" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">{t('profile.email')}</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                <input type="email" value={state.user?.email || ''} className="input-field !pl-10 opacity-60" disabled />
              </div>
            </div>
            <button onClick={handleSave} className="btn-primary text-sm">
              {saved ? <><CheckCircle size={16} /> {t('profile.saved')}</> : <><Save size={16} /> {t('profile.save')}</>}
            </button>
          </div>
        </motion.div>

        {/* Preferences */}
        <motion.div variants={fadeUp} className="glass rounded-2xl p-6 mb-6">
          <h2 className="font-semibold mb-4">Preferences</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">{t('profile.language')}</label>
              <div className="flex gap-2">
                {[{ code: 'en', flag: '🇺🇸', name: 'English' }, { code: 'ru', flag: '🇷🇺', name: 'Русский' }, { code: 'ky', flag: '🇰🇬', name: 'Кыргызча' }].map(l => (
                  <button key={l.code} onClick={() => i18n.changeLanguage(l.code)}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${i18n.language === l.code ? 'gradient-bg text-white' : 'glass'}`}>
                    <span>{l.flag}</span> {l.name}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-between p-4 rounded-xl" style={{ background: 'var(--bg-tertiary)' }}>
              <div className="flex items-center gap-3">
                {state.theme === 'dark' ? <Moon size={20} /> : <Sun size={20} />}
                <div>
                  <p className="font-medium text-sm">{t('profile.theme')}</p>
                  <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{state.theme === 'dark' ? t('profile.dark_mode') : t('profile.light_mode')}</p>
                </div>
              </div>
              <button onClick={toggleTheme} className={`w-12 h-6 rounded-full relative transition-colors ${state.theme === 'dark' ? 'bg-blue-500' : 'bg-gray-300'}`}>
                <div className={`w-5 h-5 rounded-full bg-white shadow absolute top-0.5 transition-transform ${state.theme === 'dark' ? 'translate-x-6' : 'translate-x-0.5'}`} />
              </button>
            </div>
            <div className="flex items-center justify-between p-4 rounded-xl" style={{ background: 'var(--bg-tertiary)' }}>
              <div className="flex items-center gap-3">
                <Bell size={20} />
                <div>
                  <p className="font-medium text-sm">{t('profile.notifications')}</p>
                  <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>Receive learning reminders</p>
                </div>
              </div>
              <button onClick={() => setNotifications(!notifications)} className={`w-12 h-6 rounded-full relative transition-colors ${notifications ? 'bg-blue-500' : 'bg-gray-300'}`}>
                <div className={`w-5 h-5 rounded-full bg-white shadow absolute top-0.5 transition-transform ${notifications ? 'translate-x-6' : 'translate-x-0.5'}`} />
              </button>
            </div>
            <div className="flex items-center justify-between p-4 rounded-xl" style={{ background: 'var(--bg-tertiary)' }}>
              <div className="flex items-center gap-3">
                <Volume2 size={20} />
                <div>
                  <p className="font-medium text-sm">{t('profile.sound')}</p>
                  <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>Play sounds for achievements</p>
                </div>
              </div>
              <button onClick={() => setSound(!sound)} className={`w-12 h-6 rounded-full relative transition-colors ${sound ? 'bg-blue-500' : 'bg-gray-300'}`}>
                <div className={`w-5 h-5 rounded-full bg-white shadow absolute top-0.5 transition-transform ${sound ? 'translate-x-6' : 'translate-x-0.5'}`} />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Danger Zone */}
        <motion.div variants={fadeUp} className="glass rounded-2xl p-6 border border-red-200 dark:border-red-900/30">
          <h2 className="font-semibold mb-4 text-red-500">Danger Zone</h2>
          <div className="flex flex-col sm:flex-row gap-3">
            <button className="btn-secondary text-sm">
              <Lock size={16} /> {t('profile.change_password')}
            </button>
            <button className="px-4 py-2.5 rounded-xl text-sm font-medium bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-900/20 dark:text-red-400 transition-colors">
              <Trash2 size={16} className="inline mr-2" />{t('profile.delete_account')}
            </button>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
