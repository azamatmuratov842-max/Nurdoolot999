import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Trophy, Crown, Medal, Star, Flame, TrendingUp } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { leaderboardData } from '../services/lessons';

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.06 } } };

export default function LeaderboardPage() {
  const { t } = useTranslation();
  const { state } = useApp();
  const [period, setPeriod] = useState<'weekly' | 'monthly' | 'all_time'>('weekly');

  const topThree = leaderboardData.slice(0, 3);
  const rest = leaderboardData.slice(3);

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <motion.div initial="hidden" animate="visible" variants={stagger}>
        <motion.div variants={fadeUp} className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t('leaderboard.title')}</h1>
          <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>{t('leaderboard.subtitle')}</p>
        </motion.div>

        {/* Period Tabs */}
        <motion.div variants={fadeUp} className="flex justify-center gap-2 mb-10">
          {(['weekly', 'monthly', 'all_time'] as const).map(p => (
            <button key={p} onClick={() => setPeriod(p)}
              className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${period === p ? 'gradient-bg text-white' : 'glass'}`}>
              {t(`leaderboard.${p}`)}
            </button>
          ))}
        </motion.div>

        {/* Top 3 */}
        <motion.div variants={fadeUp} className="flex items-end justify-center gap-4 mb-10">
          {[topThree[1], topThree[0], topThree[2]].map((user, i) => {
            const rank = i === 1 ? 0 : i === 0 ? 1 : 2;
            const heights = ['h-32', 'h-40', 'h-28'];
            const colors = ['from-gray-300 to-gray-400', 'from-amber-400 to-yellow-500', 'from-orange-300 to-orange-500'];
            const sizes = ['w-14 h-14', 'w-16 h-16', 'w-12 h-12'];
            const medals = ['🥈', '🥇', '🥉'];
            return (
              <motion.div key={user.rank} variants={fadeUp} className="flex flex-col items-center">
                <span className="text-3xl mb-2">{medals[rank]}</span>
                <div className={`${sizes[rank]} rounded-full bg-gradient-to-r ${colors[rank]} flex items-center justify-center text-2xl mb-2 ring-4 ring-white dark:ring-gray-800 shadow-lg`}>
                  {user.avatar}
                </div>
                <span className="font-semibold text-sm">{user.name}</span>
                <span className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{user.country}</span>
                <span className="text-sm font-bold gradient-text mt-1">{user.xp.toLocaleString()} XP</span>
                <div className={`w-20 ${heights[rank]} rounded-t-xl bg-gradient-to-t ${colors[rank]} opacity-20 mt-2`} />
              </motion.div>
            );
          })}
        </motion.div>

        {/* Rest of leaderboard */}
        <motion.div variants={stagger} className="space-y-2">
          {rest.map((user) => (
            <motion.div key={user.rank} variants={fadeUp}
              className="glass rounded-xl p-4 flex items-center gap-4 card-hover">
              <span className="w-8 text-center font-bold text-lg" style={{ color: 'var(--text-tertiary)' }}>
                #{user.rank}
              </span>
              <span className="text-2xl">{user.avatar}</span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm">{user.name}</span>
                  <span>{user.country}</span>
                </div>
                <div className="flex items-center gap-3 text-xs" style={{ color: 'var(--text-tertiary)' }}>
                  <span className="flex items-center gap-1"><Star size={12} className="text-amber-500" />Lv.{user.level}</span>
                  <span className="flex items-center gap-1"><Flame size={12} className="text-orange-500" />{user.streak} days</span>
                </div>
              </div>
              <span className="font-bold text-sm gradient-text">{user.xp.toLocaleString()} XP</span>
            </motion.div>
          ))}
        </motion.div>

        {/* Your position */}
        {state.isAuthenticated && state.user && (
          <motion.div variants={fadeUp} className="mt-6">
            <div className="glass rounded-xl p-4 flex items-center gap-4 border-2" style={{ borderColor: 'var(--gradient-start)' }}>
              <span className="w-8 text-center font-bold text-lg" style={{ color: 'var(--gradient-start)' }}>#--</span>
              <span className="text-2xl">{state.user.avatar}</span>
              <div className="flex-1">
                <span className="font-medium text-sm">{state.user.name} <span className="text-xs" style={{ color: 'var(--gradient-start)' }}>({t('leaderboard.you')})</span></span>
                <div className="flex items-center gap-3 text-xs" style={{ color: 'var(--text-tertiary)' }}>
                  <span>Lv.{state.user.level}</span>
                  <span>{state.user.streak} day streak</span>
                </div>
              </div>
              <span className="font-bold text-sm gradient-text">{state.user.xp.toLocaleString()} XP</span>
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
