import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, ArrowRight, CheckCircle, XCircle, BookOpen, Clock, Zap, RotateCcw, ChevronRight, Award, Star, Lock, Play } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { lessons } from '../services/lessons';

export default function LessonPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const { state, completeLesson, addXP, unlockAchievement } = useApp();
  const lang = i18n.language;

  const lesson = lessons.find(l => l.id === id);
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showResult, setShowResult] = useState<Record<string, boolean>>({});
  const [isComplete, setIsComplete] = useState(false);
  const [showContent, setShowContent] = useState(true);
  const [score, setScore] = useState(0);

  if (!lesson) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">Lesson not found</h1>
        <Link to="/courses" className="btn-primary"><ArrowLeft size={16} /> Back to Courses</Link>
      </div>
    );
  }

  const isLocked = lesson.isPremium && !state.user?.isPremium;
  const isCompleted = state.user?.lessonsCompleted.includes(lesson.id);
  const title = lang === 'ru' ? lesson.titleRu : lang === 'ky' ? lesson.titleKy : lesson.title;
  const content = lang === 'ru' ? lesson.contentRu : lang === 'ky' ? lesson.contentKy : lesson.content;
  const totalQ = lesson.questions.length;

  const handleAnswer = (questionId: string, answer: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const checkAnswer = (questionId: string) => {
    const q = lesson.questions.find(q => q.id === questionId);
    if (!q) return;
    const isCorrect = answers[questionId]?.toLowerCase().trim() === q.correctAnswer.toLowerCase().trim();
    setShowResult(prev => ({ ...prev, [questionId]: true }));
    if (isCorrect) setScore(s => s + 1);
  };

  const handleComplete = () => {
    if (!isCompleted) {
      completeLesson(lesson.id);
      addXP(lesson.xp);
      if (state.user && state.user.lessonsCompleted.length === 0) {
        unlockAchievement('first_lesson');
      }
    }
    setIsComplete(true);
  };

  const renderMarkdown = (text: string) => {
    return text.split('\n').map((line, i) => {
      const processed = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\*(.*?)\*/g, '<em>$1</em>');
      if (line.startsWith('•') || line.startsWith('-')) {
        return <li key={i} className="ml-4 list-disc" dangerouslySetInnerHTML={{ __html: processed.replace(/^[-•]\s*/, '') }} />;
      }
      if (line.trim() === '') return <div key={i} className="h-3" />;
      return <p key={i} dangerouslySetInnerHTML={{ __html: processed }} />;
    });
  };

  if (isLocked) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <Lock className="mx-auto mb-4 text-amber-500" size={48} />
        <h1 className="text-2xl font-bold mb-2">Premium Content</h1>
        <p className="mb-6" style={{ color: 'var(--text-secondary)' }}>This lesson requires a Premium subscription.</p>
        <Link to="/pricing" className="btn-primary">Upgrade to Premium</Link>
      </div>
    );
  }

  if (isComplete || isCompleted) {
    if (!isComplete && isCompleted) setIsComplete(true);
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
          <ArrowLeft size={20} />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-bold">{title}</h1>
          <div className="flex items-center gap-3 text-xs mt-1" style={{ color: 'var(--text-tertiary)' }}>
            <span className="flex items-center gap-1"><BookOpen size={12} />{lesson.type}</span>
            <span className="flex items-center gap-1"><Clock size={12} />{lesson.duration} min</span>
            <span className="flex items-center gap-1"><Zap size={12} />{lesson.xp} XP</span>
          </div>
        </div>
        <span className={`text-xs px-3 py-1 rounded-full ${isCompleted ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'}`}>
          {isCompleted ? t('courses.completed') : `Lv.${lesson.level}`}
        </span>
      </div>

      {/* Progress */}
      {!showContent && (
        <div className="mb-6">
          <div className="flex justify-between text-sm mb-2">
            <span>{t('lesson.question', { number: currentQ + 1 })}</span>
            <span>{currentQ + 1} {t('lesson.of')} {totalQ}</span>
          </div>
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: `${((currentQ + 1) / totalQ) * 100}%` }} />
          </div>
        </div>
      )}

      <AnimatePresence mode="wait">
        {showContent ? (
          <motion.div key="content" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}
            className="glass rounded-2xl p-6 md:p-8">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <BookOpen size={20} style={{ color: 'var(--gradient-start)' }} />
              {title}
            </h2>
            <div className="prose prose-sm max-w-none leading-relaxed" style={{ color: 'var(--text-primary)' }}>
              {renderMarkdown(content)}
            </div>
            <div className="mt-8 flex justify-between">
              <Link to="/courses" className="btn-secondary text-sm">
                <ArrowLeft size={16} /> {t('common.back')}
              </Link>
              <button onClick={() => setShowContent(false)} className="btn-primary text-sm">
                {t('lesson.next')} <ArrowRight size={16} />
              </button>
            </div>
          </motion.div>
        ) : !isComplete && !state.user?.lessonsCompleted.includes(lesson.id) ? (
          <motion.div key="quiz" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
            className="glass rounded-2xl p-6 md:p-8">
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-2">{t('lesson.question', { number: currentQ + 1 })}</h2>
              <p className="text-base">{lesson.questions[currentQ].question}</p>
            </div>

            {lesson.questions[currentQ].type === 'multiple-choice' && lesson.questions[currentQ].options && (
              <div className="space-y-3 mb-6">
                {lesson.questions[currentQ].options!.map(opt => {
                  const selected = answers[lesson.questions[currentQ].id] === opt;
                  const correct = showResult[lesson.questions[currentQ].id] && opt === lesson.questions[currentQ].correctAnswer;
                  const wrong = showResult[lesson.questions[currentQ].id] && selected && opt !== lesson.questions[currentQ].correctAnswer;
                  return (
                    <button key={opt}
                      onClick={() => !showResult[lesson.questions[currentQ].id] && handleAnswer(lesson.questions[currentQ].id, opt)}
                      className={`w-full text-left p-4 rounded-xl border-2 transition-all ${correct ? 'border-green-500 bg-green-50 dark:bg-green-900/20' : wrong ? 'border-red-500 bg-red-50 dark:bg-red-900/20' : selected ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'hover:border-gray-300 dark:hover:border-gray-600'}`}
                      style={!selected && !correct && !wrong ? { borderColor: 'var(--border-color)' } : {}}
                      disabled={!!showResult[lesson.questions[currentQ].id]}>
                      <div className="flex items-center gap-3">
                        <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${correct ? 'border-green-500 bg-green-500' : wrong ? 'border-red-500' : selected ? 'border-blue-500' : 'border-gray-300'}`}>
                          {correct && <CheckCircle size={14} className="text-white" />}
                          {wrong && <XCircle size={14} className="text-red-500" />}
                        </div>
                        <span className="text-sm">{opt}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}

            {(lesson.questions[currentQ].type === 'fill-blank' || lesson.questions[currentQ].type === 'true-false') && (
              <div className="mb-6">
                {lesson.questions[currentQ].options ? (
                  <div className="space-y-3">
                    {lesson.questions[currentQ].options!.map(opt => {
                      const selected = answers[lesson.questions[currentQ].id] === opt;
                      return (
                        <button key={opt} onClick={() => !showResult[lesson.questions[currentQ].id] && handleAnswer(lesson.questions[currentQ].id, opt)}
                          className={`w-full text-left p-4 rounded-xl border-2 transition-all ${selected ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'hover:border-gray-300'}`}
                          style={!selected ? { borderColor: 'var(--border-color)' } : {}} disabled={!!showResult[lesson.questions[currentQ].id]}>
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <input type="text" value={answers[lesson.questions[currentQ].id] || ''}
                    onChange={e => handleAnswer(lesson.questions[currentQ].id, e.target.value)}
                    placeholder="Type your answer..."
                    className="input-field text-lg"
                    disabled={!!showResult[lesson.questions[currentQ].id]} />
                )}
              </div>
            )}

            {showResult[lesson.questions[currentQ].id] && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                className={`p-4 rounded-xl mb-6 ${answers[lesson.questions[currentQ].id]?.toLowerCase().trim() === lesson.questions[currentQ].correctAnswer.toLowerCase().trim() ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800' : 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800'}`}>
                <div className="flex items-center gap-2 mb-2">
                  {answers[lesson.questions[currentQ].id]?.toLowerCase().trim() === lesson.questions[currentQ].correctAnswer.toLowerCase().trim()
                    ? <><CheckCircle className="text-green-500" size={20} /><span className="font-medium text-green-700 dark:text-green-400">{t('lesson.correct')}</span></>
                    : <><XCircle className="text-red-500" size={20} /><span className="font-medium text-red-700 dark:text-red-400">{t('lesson.incorrect')}</span></>}
                </div>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{t('lesson.explanation')}: {lesson.questions[currentQ].explanation}</p>
              </motion.div>
            )}

            <div className="flex justify-between">
              <button onClick={() => { setCurrentQ(Math.max(0, currentQ - 1)); setShowResult({}); }}
                className="btn-secondary text-sm" disabled={currentQ === 0}>
                <ArrowLeft size={16} /> {t('lesson.previous')}
              </button>
              {!showResult[lesson.questions[currentQ].id] ? (
                <button onClick={() => checkAnswer(lesson.questions[currentQ].id)}
                  className="btn-primary text-sm" disabled={!answers[lesson.questions[currentQ].id]}>
                  {t('lesson.check')} <CheckCircle size={16} />
                </button>
              ) : currentQ < totalQ - 1 ? (
                <button onClick={() => { setCurrentQ(currentQ + 1); }} className="btn-primary text-sm">
                  {t('lesson.next')} <ArrowRight size={16} />
                </button>
              ) : (
                <button onClick={handleComplete} className="btn-primary text-sm">
                  {t('lesson.complete')} <Award size={16} />
                </button>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div key="complete" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
            className="glass rounded-2xl p-8 md:p-12 text-center">
            <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 0.5, repeat: 2 }}
              className="w-20 h-20 mx-auto rounded-full gradient-bg flex items-center justify-center mb-6">
              <Award className="text-white" size={40} />
            </motion.div>
            <h2 className="text-2xl font-bold mb-2">{t('lesson.correct')}</h2>
            <p className="text-lg mb-1" style={{ color: 'var(--text-secondary)' }}>Lesson Complete!</p>
            <div className="flex items-center justify-center gap-6 my-6">
              <div className="text-center">
                <div className="text-3xl font-bold gradient-text">{score}/{totalQ}</div>
                <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>{t('lesson.score')}</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-amber-500">+{lesson.xp}</div>
                <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>XP</div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link to="/courses" className="btn-secondary">
                <ArrowLeft size={16} /> {t('common.back')}
              </Link>
              <Link to="/dashboard" className="btn-primary">
                {t('nav.dashboard')} <ArrowRight size={16} />
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
