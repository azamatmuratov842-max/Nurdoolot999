import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Clock, Send, CheckCircle, MessageSquare, User, FileText } from 'lucide-react';

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.1 } } };

export default function ContactPage() {
  const { t } = useTranslation();
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [isSent, setIsSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 1000));
    setIsLoading(false);
    setIsSent(true);
    setFormData({ name: '', email: '', subject: '', message: '' });
    setTimeout(() => setIsSent(false), 5000);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <motion.div initial="hidden" animate="visible" variants={stagger}>
        <motion.div variants={fadeUp} className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t('contact.title')}</h1>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: 'var(--text-secondary)' }}>{t('contact.subtitle')}</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact Info */}
          <motion.div variants={fadeUp} className="space-y-4">
            <div className="glass rounded-xl p-5 card-hover">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                  <Mail size={18} className="text-blue-500" />
                </div>
                <div>
                  <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{t('contact.email_label')}</p>
                  <p className="font-medium text-sm">hello@akkula.com</p>
                </div>
              </div>
            </div>
            <div className="glass rounded-xl p-5 card-hover">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                  <Phone size={18} className="text-green-500" />
                </div>
                <div>
                  <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{t('contact.phone_label')}</p>
                  <p className="font-medium text-sm">+996 312 123 456</p>
                </div>
              </div>
            </div>
            <div className="glass rounded-xl p-5 card-hover">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                  <MapPin size={18} className="text-purple-500" />
                </div>
                <div>
                  <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{t('contact.address_label')}</p>
                  <p className="font-medium text-sm">Bishkek, Kyrgyzstan</p>
                </div>
              </div>
            </div>
            <div className="glass rounded-xl p-5 card-hover">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-lg bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                  <Clock size={18} className="text-amber-500" />
                </div>
                <div>
                  <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{t('contact.hours_label')}</p>
                  <p className="font-medium text-sm">{t('contact.hours')}</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div variants={fadeUp} className="lg:col-span-2">
            <div className="glass rounded-2xl p-6 md:p-8">
              {isSent ? (
                <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-12">
                  <CheckCircle className="mx-auto mb-4 text-green-500" size={48} />
                  <h3 className="text-xl font-bold mb-2">{t('contact.success')}</h3>
                  <p style={{ color: 'var(--text-secondary)' }}>We'll get back to you as soon as possible.</p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-1 block">{t('contact.name')}</label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                        <input type="text" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} className="input-field !pl-10" />
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-1 block">{t('contact.email')}</label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                        <input type="email" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} className="input-field !pl-10" />
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">{t('contact.subject')}</label>
                    <div className="relative">
                      <FileText className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                      <input type="text" value={formData.subject} onChange={e => setFormData({ ...formData, subject: e.target.value })} className="input-field !pl-10" />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">{t('contact.message')}</label>
                    <textarea value={formData.message} onChange={e => setFormData({ ...formData, message: e.target.value })} className="input-field h-36 resize-none" />
                  </div>
                  <button type="submit" className="btn-primary" disabled={isLoading}>
                    {isLoading ? 'Sending...' : <><Send size={16} /> {t('contact.send')}</>}
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
