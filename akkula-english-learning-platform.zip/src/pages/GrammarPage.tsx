import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { GraduationCap, BookOpen, ArrowRight, ChevronRight, Clock, Zap, Play } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import { lessons } from '../services/lessons';

const grammarTopics = [
  { id: 'tenses', icon: '⏰', color: 'from-blue-500 to-cyan-500', lessonId: 'l2' },
  { id: 'articles', icon: '📝', color: 'from-green-500 to-emerald-500', lessonId: 'l3' },
  { id: 'conditionals', icon: '🔀', color: 'from-purple-500 to-violet-500', lessonId: 'l8' },
  { id: 'passive_voice', icon: '🔄', color: 'from-amber-500 to-orange-500', lessonId: 'l4' },
  { id: 'modal_verbs', icon: '⚡', color: 'from-rose-500 to-pink-500', lessonId: 'l6' },
  { id: 'reported_speech', icon: '💬', color: 'from-indigo-500 to-blue-500', lessonId: 'l4' },
  { id: 'prepositions', icon: '📍', color: 'from-teal-500 to-green-500', lessonId: 'l5' },
  { id: 'relative_clauses', icon: '🔗', color: 'from-fuchsia-500 to-purple-500', lessonId: 'l6' },
];

const grammarExplanations: Record<string, { en: string; ru: string; ky: string }> = {
  tenses: {
    en: "English has 12 tenses divided into past, present, and future. Each has simple, continuous, and perfect forms.\n\n• Present Simple: I work\n• Present Continuous: I am working\n• Present Perfect: I have worked\n• Past Simple: I worked\n• Past Continuous: I was working\n• Past Perfect: I had worked\n• Future Simple: I will work\n• Future Continuous: I will be working\n• Future Perfect: I will have worked",
    ru: "В английском 12 времён, разделённых на прошедшее, настоящее и будущее.\n\n• Present Simple: I work\n• Present Continuous: I am working\n• Present Perfect: I have worked\n• Past Simple: I worked\n• Past Continuous: I was working\n• Past Perfect: I had worked\n• Future Simple: I will work",
    ky: "Англис тилинде 12 чак бар, ѳткѳн, учур жана келечек болуп бѳлүнѳт.\n\n• Present Simple: I work\n• Present Continuous: I am working\n• Present Perfect: I have worked\n• Past Simple: I worked",
  },
  articles: {
    en: "English uses three articles: a, an, the.\n\n'A/An' — indefinite article:\n• A book, a university\n• An apple, an hour\n\n'The' — definite article:\n• The sun is bright\n• The book I told you about\n\nNo article with:\n• General plurals: I love dogs\n• Uncountable nouns: I love music",
    ru: "В английском три артикля: a, an, the.\n\n'A/An' — неопределённый артикль\n'The' — определённый артикль\n\nБез артикля:\n• Общий множественное число\n• Неисчисляемые существительные",
    ky: "Англис тилинде ѳч артикль бар: a, an, the.\n\n'A/An' — аныксыз артикль\n'The' — аныктуу артикль",
  },
  conditionals: {
    en: "Conditionals describe hypothetical situations:\n\n• Zero: If + present, present (facts)\n• First: If + present, will + V1 (real future)\n• Second: If + past, would + V1 (unreal present)\n• Third: If + past perfect, would have + V3 (unreal past)",
    ru: "Условные предложения описывают гипотетические ситуации:\n\n• Нулевое: факты\n• Первое: реальное будущее\n• Второе: нереальное настоящее\n• Третье: нереальное прошлое",
    ky: "Шарттуу сүйлѳмдѳр божомолдоо абалдарды сыпаттайт.",
  },
  passive_voice: {
    en: "The passive voice focuses on the action rather than who performs it:\n\nStructure: Subject + be + V3\n\n• Active: She writes letters\n• Passive: Letters are written by her\n\nTenses: is/are + V3, was/were + V3, will be + V3",
    ru: "Страдательный залог фокусируется на действии, а не на деятеле:\n\nСтруктура: Подлежащее + be + V3\n\n• Действительный: Она пишет письма\n• Страдательный: Письма написаны ею",
    ky: "Ѳӊдѳмѳ заалым аракетке, аны жасаган адамга эмес кѳӊүл бурат.",
  },
  modal_verbs: {
    en: "Modal verbs express ability, possibility, permission, or obligation:\n\n• Can/Could: ability, possibility\n• Must/Have to: obligation\n• Should: advice\n• May/Might: possibility\n• Would: conditional\n\nModals are always followed by the base form (V1).",
    ru: "Модальные глаголы выражают способность, возможность, разрешение или обязательство:\n\n• Can/Could: способность\n• Must: обязательство\n• Should: совет\n• May/Might: возможность",
    ky: "Модалдык этиштер жۅндɵмдүүлүктү, мүмкүндүктү, уруксатты билдирет.",
  },
  reported_speech: {
    en: "Reported speech conveys what someone said:\n\n• Direct: She said, 'I am happy.'\n• Reported: She said (that) she was happy.\n\nTense changes:\n• Present → Past\n• Will → Would\n• Can → Could",
    ru: "Косвенная речь передаёт чьи-то слова:\n\n• Прямая: She said, 'I am happy.'\n• Косвенная: She said she was happy.",
    ky: "Кыйыр сүйлѳѳ бирѳѳнүн сѳзүн берет.",
  },
  prepositions: {
    en: "Prepositions show relationships between words:\n\n• Time: at 5pm, on Monday, in January\n• Place: at home, on the table, in the room\n• Direction: to the store, into the house\n\nCommon prepositional phrases:\n• Interested in, good at, afraid of",
    ru: "Предлоги показывают отношения между словами:\n\n• Время: at 5pm, on Monday, in January\n• Место: at home, on the table\n• Направление: to the store",
    ky: "Предлогтор сѳздѳрдүн ортосундагы мамилелерди кѳрсѳтѳт.",
  },
  relative_clauses: {
    en: "Relative clauses provide additional information:\n\n• Who (people): The man who called\n• Which (things): The book which I read\n• That (both): The car that I bought\n• Where (place): The city where I live\n• When (time): The day when we met",
    ru: "Определительные предложения дают дополнительную информацию:\n\n• Who (люди)\n• Which (вещи)\n• That (оба)\n• Where (место)\n• When (время)",
    ky: "Ѳӊдѳѳ сүйлѳмдѳрү кошумча маалымат берет.",
  },
};

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.08 } } };

export default function GrammarPage() {
  const { t, i18n } = useTranslation();
  const lang = i18n.language as 'en' | 'ru' | 'ky';
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <motion.div initial="hidden" animate="visible" variants={stagger}>
        <motion.div variants={fadeUp} className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t('grammar.title')}</h1>
          <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>{t('grammar.subtitle')}</p>
        </motion.div>

        {selectedTopic ? (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <button onClick={() => setSelectedTopic(null)} className="btn-secondary mb-6 text-sm">
              ← {t('common.back')}
            </button>
            <div className="glass rounded-2xl p-6 md:p-8 mb-6">
              <h2 className="text-xl font-bold mb-4 capitalize">{t(`grammar.${selectedTopic}`)}</h2>
              <div className="leading-relaxed whitespace-pre-line" style={{ color: 'var(--text-primary)' }}>
                {grammarExplanations[selectedTopic]?.[lang] || grammarExplanations[selectedTopic]?.en}
              </div>
            </div>
            <div className="flex gap-4">
              <Link to={`/lesson/${grammarTopics.find(g => g.id === selectedTopic)?.lessonId || 'l2'}`} className="btn-primary">
                <Play size={16} /> Practice This Topic
              </Link>
            </div>
          </motion.div>
        ) : (
          <motion.div variants={stagger} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {grammarTopics.map(topic => {
              const lesson = lessons.find(l => l.id === topic.lessonId);
              return (
                <motion.button key={topic.id} variants={fadeUp}
                  onClick={() => setSelectedTopic(topic.id)}
                  className="glass rounded-2xl p-6 text-left card-hover group">
                  <div className="text-3xl mb-3">{topic.icon}</div>
                  <h3 className="font-semibold mb-1">{t(`grammar.${topic.id}`)}</h3>
                  <p className="text-xs mb-3" style={{ color: 'var(--text-tertiary)' }}>
                    {lesson ? `${lesson.duration} min • ${lesson.xp} XP` : 'Learn more'}
                  </p>
                  <div className="flex items-center gap-1 text-sm font-medium group-hover:gap-2 transition-all" style={{ color: 'var(--gradient-start)' }}>
                    Explore <ChevronRight size={16} />
                  </div>
                </motion.button>
              );
            })}
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
