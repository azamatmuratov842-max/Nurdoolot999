import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Mail, Lock, User, Eye, EyeOff, ArrowRight, Loader2, AlertCircle, CheckCircle } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

export default function AuthPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const location = useLocation();
  const { login, register, loginWithGoogle, resetPassword } = useApp();
  const isLogin = location.pathname === '/login';

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showReset, setShowReset] = useState(false);
  const [resetEmail, setResetEmail] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email || !password) { setError('Please fill in all fields'); return; }
    if (!isLogin && !name) { setError('Please enter your name'); return; }
    if (!isLogin && password !== confirmPassword) { setError('Passwords do not match'); return; }
    if (!isLogin && password.length < 6) { setError('Password must be at least 6 characters'); return; }

    setIsLoading(true);
    const result = isLogin ? await login(email, password) : await register(name, email, password);
    setIsLoading(false);

    if (result.success) {
      navigate('/dashboard');
    } else {
      setError(result.error || 'Something went wrong');
    }
  };

  const handleGoogle = async () => {
    setIsLoading(true);
    const result = await loginWithGoogle();
    setIsLoading(false);
    if (result.success) navigate('/dashboard');
    else setError(result.error || 'Google login failed');
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetEmail) return;
    setIsLoading(true);
    const result = await resetPassword(resetEmail);
    setIsLoading(false);
    if (result.success) setSuccess(t('auth.reset_sent'));
    else setError(result.error || 'Error sending reset email');
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-12">
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-blue-400/30 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 rounded-full bg-purple-400/30 blur-3xl" />
      </div>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md relative z-10">
        <div className="glass rounded-2xl p-8">
          <div className="text-center mb-8">
            <div className="w-14 h-14 mx-auto rounded-2xl gradient-bg flex items-center justify-center text-white font-bold text-2xl mb-4">A</div>
            <h1 className="text-2xl font-bold">{isLogin ? t('auth.login_title') : t('auth.register_title')}</h1>
            <p className="text-sm mt-2" style={{ color: 'var(--text-secondary)' }}>
              {isLogin ? t('auth.login_subtitle') : t('auth.register_subtitle')}
            </p>
          </div>

          {showReset ? (
            <form onSubmit={handleReset} className="space-y-4">
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{t('auth.reset_password')}</p>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                <input type="email" value={resetEmail} onChange={e => setResetEmail(e.target.value)} placeholder={t('auth.email')} className="input-field !pl-10" />
              </div>
              {success && <div className="flex items-center gap-2 text-green-600 text-sm"><CheckCircle size={16} />{success}</div>}
              {error && <div className="flex items-center gap-2 text-red-500 text-sm"><AlertCircle size={16} />{error}</div>}
              <button type="submit" className="btn-primary w-full" disabled={isLoading}>
                {isLoading ? <Loader2 className="animate-spin" size={18} /> : t('auth.reset_password')}
              </button>
              <button type="button" onClick={() => setShowReset(false)} className="w-full text-sm text-center" style={{ color: 'var(--gradient-start)' }}>
                {t('auth.sign_in')}
              </button>
            </form>
          ) : (
            <>
              <form onSubmit={handleSubmit} className="space-y-4">
                {!isLogin && (
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                    <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder={t('auth.name')} className="input-field !pl-10" />
                  </div>
                )}
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder={t('auth.email')} className="input-field !pl-10" />
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                  <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder={t('auth.password')} className="input-field !pl-10 !pr-10" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }}>
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
                {!isLogin && (
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--text-tertiary)' }} size={18} />
                    <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder={t('auth.confirm_password')} className="input-field !pl-10" />
                  </div>
                )}
                {isLogin && (
                  <div className="flex items-center justify-between">
                    <label className="flex items-center gap-2 text-sm cursor-pointer">
                      <input type="checkbox" checked={rememberMe} onChange={e => setRememberMe(e.target.checked)} className="w-4 h-4 rounded" />
                      {t('auth.remember_me')}
                    </label>
                    <button type="button" onClick={() => setShowReset(true)} className="text-sm hover:underline" style={{ color: 'var(--gradient-start)' }}>
                      {t('auth.forgot_password')}
                    </button>
                  </div>
                )}
                {error && <div className="flex items-center gap-2 text-red-500 text-sm"><AlertCircle size={16} />{error}</div>}
                <button type="submit" className="btn-primary w-full" disabled={isLoading}>
                  {isLoading ? <Loader2 className="animate-spin" size={18} /> : <>{isLogin ? t('auth.login_btn') : t('auth.register_btn')} <ArrowRight size={18} /></>}
                </button>
              </form>

              <div className="flex items-center gap-3 my-6">
                <div className="flex-1 h-px" style={{ background: 'var(--border-color)' }} />
                <span className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{t('auth.or')}</span>
                <div className="flex-1 h-px" style={{ background: 'var(--border-color)' }} />
              </div>

              <button onClick={handleGoogle} className="btn-secondary w-full" disabled={isLoading}>
                <svg className="w-5 h-5" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                {t('auth.google_btn')}
              </button>

              <p className="text-center text-sm mt-6" style={{ color: 'var(--text-secondary)' }}>
                {isLogin ? t('auth.no_account') : t('auth.have_account')}{' '}
                <Link to={isLogin ? '/register' : '/login'} className="font-semibold hover:underline" style={{ color: 'var(--gradient-start)' }}>
                  {isLogin ? t('auth.sign_up') : t('auth.sign_in')}
                </Link>
              </p>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}
