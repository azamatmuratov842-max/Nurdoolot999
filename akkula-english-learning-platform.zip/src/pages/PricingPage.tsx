import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { CheckCircle, Crown, Zap, ArrowRight, Shield, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.1 } } };

export default function PricingPage() {
  const { t } = useTranslation();
  const { state } = useApp();

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <motion.div initial="hidden" animate="visible" variants={stagger}>
        <motion.div variants={fadeUp} className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{t('pricing.title')}</h1>
          <p className="text-lg" style={{ color: 'var(--text-secondary)' }}>{t('pricing.subtitle')}</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Free Plan */}
          <motion.div variants={fadeUp} className="glass rounded-2xl p-8 relative">
            <div className="mb-6">
              <div className="w-12 h-12 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center mb-4">
                <Zap size={24} style={{ color: 'var(--text-secondary)' }} />
              </div>
              <h2 className="text-2xl font-bold">{t('pricing.free')}</h2>
              <div className="mt-2">
                <span className="text-4xl font-bold">0</span>
                <span className="text-lg ml-1" style={{ color: 'var(--text-secondary)' }}>{t('pricing.currency')}{t('pricing.month')}</span>
              </div>
            </div>
            <ul className="space-y-3 mb-8">
              {(t('pricing.free_features', { returnObjects: true }) as string[]).map((f: string, i: number) => (
                <li key={i} className="flex items-center gap-3 text-sm">
                  <CheckCircle size={18} className="text-green-500 shrink-0" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
            {state.user?.isPremium ? (
              <div className="btn-secondary w-full justify-center opacity-60">{t('pricing.current_plan')}</div>
            ) : (
              <div className="btn-secondary w-full justify-center">{t('pricing.current_plan')}</div>
            )}
          </motion.div>

          {/* Premium Plan */}
          <motion.div variants={fadeUp} className="rounded-2xl p-8 relative overflow-hidden border-2" style={{ borderColor: 'var(--gradient-start)' }}>
            <div className="absolute top-0 right-0 gradient-bg text-white text-xs font-bold px-4 py-1.5 rounded-bl-xl">
              {t('pricing.popular')}
            </div>
            <div className="absolute inset-0 opacity-5">
              <div className="absolute top-10 right-10 w-40 h-40 rounded-full bg-blue-500 blur-3xl" />
              <div className="absolute bottom-10 left-10 w-40 h-40 rounded-full bg-purple-500 blur-3xl" />
            </div>
            <div className="relative z-10">
              <div className="mb-6">
                <div className="w-12 h-12 rounded-xl gradient-bg flex items-center justify-center mb-4">
                  <Crown size={24} className="text-white" />
                </div>
                <h2 className="text-2xl font-bold">{t('pricing.premium')}</h2>
                <div className="mt-2">
                  <span className="text-4xl font-bold gradient-text">499</span>
                  <span className="text-lg ml-1" style={{ color: 'var(--text-secondary)' }}>{t('pricing.currency')}{t('pricing.month')}</span>
                </div>
              </div>
              <ul className="space-y-3 mb-8">
                {(t('pricing.premium_features', { returnObjects: true }) as string[]).map((f: string, i: number) => (
                  <li key={i} className="flex items-center gap-3 text-sm">
                    <CheckCircle size={18} className="text-green-500 shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              {state.user?.isPremium ? (
                <div className="w-full py-3 rounded-xl bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 text-center font-semibold flex items-center justify-center gap-2">
                  <CheckCircle size={18} /> Active Plan
                </div>
              ) : (
                <Link to="/register" className="btn-primary w-full text-lg !py-3.5">
                  <Crown size={18} /> {t('pricing.upgrade')} <ArrowRight size={18} />
                </Link>
              )}
            </div>
          </motion.div>
        </div>

        {/* Trust badges */}
        <motion.div variants={fadeUp} className="flex flex-wrap items-center justify-center gap-8 mt-16">
          {[
            { icon: Shield, label: 'Secure Payment' },
            { icon: Star, label: '30-Day Guarantee' },
            { icon: Zap, label: 'Instant Access' },
          ].map((badge, i) => (
            <div key={i} className="flex items-center gap-2" style={{ color: 'var(--text-secondary)' }}>
              <badge.icon size={18} />
              <span className="text-sm font-medium">{badge.label}</span>
            </div>
          ))}
        </motion.div>
      </motion.div>
    </div>
  );
}
