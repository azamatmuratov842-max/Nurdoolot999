import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, ArrowLeft, ArrowRight, RotateCcw, CheckCircle, X, Volume2, Star, Flame } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { vocabularyCards } from '../services/lessons';

export default function VocabularyPage() {
  const { t, i18n } = useTranslation();
  const { state, addXP } = useApp();
  const lang = i18n.language;
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [mastered, setMastered] = useState<string[]>([]);
  const [learning, setLearning] = useState<string[]>([]);
  const [filter, setFilter] = useState<'all' | 'learning' | 'mastered'>('all');

  const filteredCards = vocabularyCards.filter(c => {
    if (filter === 'learning') return learning.includes(c.id);
    if (filter === 'mastered') return mastered.includes(c.id);
    return true;
  });

  const card = filteredCards[currentIndex] || filteredCards[0];
  const meaning = lang === 'ru' ? card?.meaningRu : lang === 'ky' ? card?.meaningKy : card?.meaning;

  const handleKnow = () => {
    if (!card) return;
    if (!mastered.includes(card.id)) setMastered([...mastered, card.id]);
    setLearning(learning.filter(id => id !== card.id));
    addXP(5);
    nextCard();
  };

  const handleLearn = () => {
    if (!card) return;
    if (!learning.includes(card.id)) setLearning([...learning, card.id]);
    nextCard();
  };

  const nextCard = () => {
    setIsFlipped(false);
    if (currentIndex < filteredCards.length - 1) setCurrentIndex(currentIndex + 1);
    else setCurrentIndex(0);
  };

  const prevCard = () => {
    setIsFlipped(false);
    if (currentIndex > 0) setCurrentIndex(currentIndex - 1);
    else setCurrentIndex(filteredCards.length - 1);
  };

  if (!card) return null;

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">{t('vocabulary.title')}</h1>
          <p style={{ color: 'var(--text-secondary)' }}>{t('vocabulary.subtitle')}</p>
        </div>

        {/* Stats */}
        <div className="flex justify-center gap-6 mb-8">
          <div className="text-center">
            <div className="flex items-center gap-1 text-green-500"><CheckCircle size={18} /><span className="text-xl font-bold">{mastered.length}</span></div>
            <span className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{t('vocabulary.mastered')}</span>
          </div>
          <div className="text-center">
            <div className="flex items-center gap-1 text-amber-500"><Brain size={18} /><span className="text-xl font-bold">{learning.length}</span></div>
            <span className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{t('vocabulary.learning')}</span>
          </div>
          <div className="text-center">
            <div className="flex items-center gap-1" style={{ color: 'var(--gradient-start)' }}><Star size={18} /><span className="text-xl font-bold">{vocabularyCards.length - mastered.length - learning.length}</span></div>
            <span className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{t('vocabulary.new_words')}</span>
          </div>
        </div>

        {/* Filter */}
        <div className="flex justify-center gap-2 mb-8">
          {(['all', 'learning', 'mastered'] as const).map(f => (
            <button key={f} onClick={() => { setFilter(f); setCurrentIndex(0); setIsFlipped(false); }}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${filter === f ? 'gradient-bg text-white' : 'glass'}`}>
              {f === 'all' ? `All (${vocabularyCards.length})` : f === 'learning' ? `${t('vocabulary.learning')} (${learning.length})` : `${t('vocabulary.mastered')} (${mastered.length})`}
            </button>
          ))}
        </div>

        {/* Card */}
        <div className="flex justify-center mb-8">
          <div className="w-full max-w-lg" style={{ perspective: '1000px' }}>
            <AnimatePresence mode="wait">
              <motion.div
                key={`${card.id}-${isFlipped}`}
                initial={{ opacity: 0, rotateY: isFlipped ? -90 : 90 }}
                animate={{ opacity: 1, rotateY: 0 }}
                exit={{ opacity: 0, rotateY: isFlipped ? 90 : -90 }}
                transition={{ duration: 0.3 }}
                onClick={() => setIsFlipped(!isFlipped)}
                className="glass rounded-2xl p-8 md:p-12 text-center cursor-pointer min-h-[300px] flex flex-col items-center justify-center card-hover"
              >
                {!isFlipped ? (
                  <>
                    <span className="text-xs px-3 py-1 rounded-full mb-4" style={{ background: 'var(--bg-tertiary)', color: 'var(--text-tertiary)' }}>Level {card.level}</span>
                    <h2 className="text-3xl md:text-4xl font-bold mb-2">{card.word}</h2>
                    <p className="text-lg mb-4" style={{ color: 'var(--text-secondary)' }}>{card.pronunciation}</p>
                    <p className="text-sm" style={{ color: 'var(--text-tertiary)' }}>Click to reveal meaning</p>
                  </>
                ) : (
                  <>
                    <h2 className="text-2xl font-bold mb-4 gradient-text">{card.word}</h2>
                    <p className="text-lg mb-4">{meaning}</p>
                    <div className="p-3 rounded-xl w-full" style={{ background: 'var(--bg-tertiary)' }}>
                      <p className="text-sm italic" style={{ color: 'var(--text-secondary)' }}>"{card.example}"</p>
                    </div>
                  </>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-4">
          <button onClick={prevCard} className="btn-secondary !p-3"><ArrowLeft size={20} /></button>
          <button onClick={handleLearn} className="px-6 py-3 rounded-xl bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 font-medium text-sm hover:opacity-80 transition-all">
            <RotateCcw size={16} className="inline mr-2" />{t('vocabulary.learn')}
          </button>
          <button onClick={() => setIsFlipped(!isFlipped)} className="btn-primary">
            {isFlipped ? <><ArrowRight size={16} /> Next</> : <>{t('vocabulary.flip')}</>}
          </button>
          <button onClick={handleKnow} className="px-6 py-3 rounded-xl bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 font-medium text-sm hover:opacity-80 transition-all">
            <CheckCircle size={16} className="inline mr-2" />{t('vocabulary.know_it')}
          </button>
          <button onClick={nextCard} className="btn-secondary !p-3"><ArrowRight size={20} /></button>
        </div>

        <p className="text-center text-sm mt-4" style={{ color: 'var(--text-tertiary)' }}>
          {currentIndex + 1} / {filteredCards.length}
        </p>
      </motion.div>
    </div>
  );
}
