import { useTranslation } from 'react-i18next';
import { motion } from 'framer-motion';
import { Target, Lightbulb, Globe, Award, Users, Heart, Rocket, Shield } from 'lucide-react';

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.1 } } };

export default function AboutPage() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="py-20 px-4 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 left-1/4 w-72 h-72 rounded-full bg-blue-400/30 blur-3xl" />
          <div className="absolute bottom-20 right-1/4 w-72 h-72 rounded-full bg-purple-400/30 blur-3xl" />
        </div>
        <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-4xl mx-auto relative z-10">
          <motion.h1 variants={fadeUp} className="text-4xl md:text-5xl font-bold mb-6">{t('about.title')}</motion.h1>
          <motion.p variants={fadeUp} className="text-lg md:text-xl leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{t('about.subtitle')}</motion.p>
        </motion.div>
      </section>

      {/* Mission */}
      <section className="py-16 px-4" style={{ background: 'var(--bg-secondary)' }}>
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} className="glass rounded-2xl p-8 md:p-12 text-center">
            <Target className="mx-auto mb-4 text-blue-500" size={40} />
            <h2 className="text-2xl font-bold mb-4">{t('about.mission_title')}</h2>
            <p className="text-lg leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{t('about.mission_desc')}</p>
          </motion.div>
        </motion.div>
      </section>

      {/* Values */}
      <section className="py-16 px-4">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="max-w-5xl mx-auto">
          <motion.h2 variants={fadeUp} className="text-3xl font-bold text-center mb-12">{t('about.values_title')}</motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: t('about.innovation'), desc: t('about.innovation_desc'), icon: Lightbulb, color: 'from-blue-500 to-cyan-500' },
              { title: t('about.accessibility'), desc: t('about.accessibility_desc'), icon: Globe, color: 'from-purple-500 to-violet-500' },
              { title: t('about.excellence'), desc: t('about.excellence_desc'), icon: Award, color: 'from-amber-500 to-orange-500' },
            ].map((value, i) => (
              <motion.div key={i} variants={fadeUp} className="glass rounded-2xl p-8 text-center card-hover">
                <div className={`w-14 h-14 mx-auto rounded-2xl bg-gradient-to-r ${value.color} flex items-center justify-center mb-4`}>
                  <value.icon className="text-white" size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">{value.title}</h3>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>{value.desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Team */}
      <section className="py-16 px-4" style={{ background: 'var(--bg-secondary)' }}>
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="max-w-5xl mx-auto">
          <motion.div variants={fadeUp} className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">{t('about.team_title')}</h2>
            <p style={{ color: 'var(--text-secondary)' }}>{t('about.team_desc')}</p>
          </motion.div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { name: 'Aida Toktosunova', role: 'Founder & CEO', emoji: '👩‍💼' },
              { name: 'Dmitry Petrov', role: 'CTO', emoji: '👨‍💻' },
              { name: 'Sarah Johnson', role: 'Head of Education', emoji: '👩‍🏫' },
              { name: 'Nuriza Almazova', role: 'Lead Designer', emoji: '👩‍🎨' },
            ].map((member, i) => (
              <motion.div key={i} variants={fadeUp} className="glass rounded-2xl p-6 text-center card-hover">
                <span className="text-5xl block mb-3">{member.emoji}</span>
                <h3 className="font-semibold text-sm">{member.name}</h3>
                <p className="text-xs" style={{ color: 'var(--text-tertiary)' }}>{member.role}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Stats */}
      <section className="py-16 px-4">
        <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { value: '50,000+', label: 'Students', icon: Users },
            { value: '120+', label: 'Countries', icon: Globe },
            { value: '500+', label: 'Lessons', icon: Rocket },
            { value: '4.9★', label: 'Rating', icon: Heart },
          ].map((stat, i) => (
            <motion.div key={i} variants={fadeUp} className="text-center">
              <stat.icon className="mx-auto mb-2" style={{ color: 'var(--gradient-start)' }} size={24} />
              <div className="text-3xl font-bold gradient-text">{stat.value}</div>
              <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </section>
    </div>
  );
}
