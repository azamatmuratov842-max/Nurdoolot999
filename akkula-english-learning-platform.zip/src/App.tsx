import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Navbar, Footer } from './components/Layout';
import AIAssistant from './components/AIAssistant';
import HomePage from './pages/HomePage';
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import CoursesPage from './pages/CoursesPage';
import LessonPage from './pages/LessonPage';
import AdminPage from './pages/AdminPage';
import PricingPage from './pages/PricingPage';
import VocabularyPage from './pages/VocabularyPage';
import GrammarPage from './pages/GrammarPage';
import PracticePage from './pages/PracticePage';
import LeaderboardPage from './pages/LeaderboardPage';
import AchievementsPage from './pages/AchievementsPage';
import ProfilePage from './pages/ProfilePage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import { useEffect } from 'react';
import { useApp } from './contexts/AppContext';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

function PageWrapper({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.25 }}
    >
      {children}
    </motion.div>
  );
}

function AppRoutes() {
  const location = useLocation();
  const { updateStreak } = useApp();

  useEffect(() => {
    updateStreak();
  }, []);

  return (
    <>
      <ScrollToTop />
      <Navbar />
      <main className="min-h-[calc(100vh-4rem)]" style={{ background: 'var(--bg-primary)', color: 'var(--text-primary)' }}>
        <AnimatePresence mode="wait">
          <Routes location={location} key={location.pathname}>
            <Route path="/" element={<PageWrapper><HomePage /></PageWrapper>} />
            <Route path="/login" element={<PageWrapper><AuthPage /></PageWrapper>} />
            <Route path="/register" element={<PageWrapper><AuthPage /></PageWrapper>} />
            <Route path="/dashboard" element={<PageWrapper><DashboardPage /></PageWrapper>} />
            <Route path="/courses" element={<PageWrapper><CoursesPage /></PageWrapper>} />
            <Route path="/lesson/:id" element={<PageWrapper><LessonPage /></PageWrapper>} />
            <Route path="/admin" element={<PageWrapper><AdminPage /></PageWrapper>} />
            <Route path="/pricing" element={<PageWrapper><PricingPage /></PageWrapper>} />
            <Route path="/vocabulary" element={<PageWrapper><VocabularyPage /></PageWrapper>} />
            <Route path="/grammar" element={<PageWrapper><GrammarPage /></PageWrapper>} />
            <Route path="/practice" element={<PageWrapper><PracticePage /></PageWrapper>} />
            <Route path="/leaderboard" element={<PageWrapper><LeaderboardPage /></PageWrapper>} />
            <Route path="/achievements" element={<PageWrapper><AchievementsPage /></PageWrapper>} />
            <Route path="/profile" element={<PageWrapper><ProfilePage /></PageWrapper>} />
            <Route path="/about" element={<PageWrapper><AboutPage /></PageWrapper>} />
            <Route path="/contact" element={<PageWrapper><ContactPage /></PageWrapper>} />
            <Route path="*" element={
              <PageWrapper>
                <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
                  <span className="text-6xl mb-4">🔍</span>
                  <h1 className="text-3xl font-bold mb-2">Page Not Found</h1>
                  <p style={{ color: 'var(--text-secondary)' }}>The page you're looking for doesn't exist.</p>
                  <a href="/" className="btn-primary mt-6">Go Home</a>
                </div>
              </PageWrapper>
            } />
          </Routes>
        </AnimatePresence>
      </main>
      <Footer />
      <AIAssistant />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  );
}
