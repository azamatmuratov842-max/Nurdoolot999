import React, { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  level: number;
  xp: number;
  streak: number;
  lessonsCompleted: string[];
  achievements: string[];
  isPremium: boolean;
  role: 'user' | 'admin';
  joinedAt: string;
  lastActive: string;
  dailyMinutes: number;
  banned: boolean;
}

export interface AppState {
  user: User | null;
  theme: 'light' | 'dark';
  isAuthenticated: boolean;
  isLoading: boolean;
  sidebarOpen: boolean;
  aiChatOpen: boolean;
}

interface AppContextType {
  state: AppState;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  resetPassword: (email: string) => Promise<{ success: boolean; error?: string }>;
  toggleTheme: () => void;
  toggleSidebar: () => void;
  toggleAiChat: () => void;
  updateProfile: (data: Partial<User>) => void;
  addXP: (amount: number) => void;
  completeLesson: (lessonId: string) => void;
  unlockAchievement: (id: string) => void;
  isAdmin: () => boolean;
  getAllUsers: () => User[];
  banUser: (userId: string) => void;
  unbanUser: (userId: string) => void;
  updateStreak: () => void;
}

const defaultState: AppState = {
  user: null,
  theme: 'light',
  isAuthenticated: false,
  isLoading: true,
  sidebarOpen: false,
  aiChatOpen: false,
};

const ADMIN_EMAIL = 'admin@akkula.com';
const ADMIN_PASSWORD = 'AkkulaAdmin2026';

const AppContext = createContext<AppContextType | undefined>(undefined);

function getStoredUsers(): User[] {
  try {
    return JSON.parse(localStorage.getItem('akkula_users') || '[]');
  } catch { return []; }
}

function saveUsers(users: User[]) {
  localStorage.setItem('akkula_users', JSON.stringify(users));
}

function getStoredTheme(): 'light' | 'dark' {
  const t = localStorage.getItem('akkula_theme');
  if (t === 'dark' || t === 'light') return t;
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>({ ...defaultState, theme: getStoredTheme() });

  useEffect(() => {
    const stored = localStorage.getItem('akkula_current_user');
    if (stored) {
      try {
        const user = JSON.parse(stored) as User;
        const users = getStoredUsers();
        const fresh = users.find(u => u.id === user.id);
        if (fresh && !fresh.banned) {
          setState(s => ({ ...s, user: fresh, isAuthenticated: true, isLoading: false }));
        } else {
          localStorage.removeItem('akkula_current_user');
          setState(s => ({ ...s, isLoading: false }));
        }
      } catch {
        setState(s => ({ ...s, isLoading: false }));
      }
    } else {
      setState(s => ({ ...s, isLoading: false }));
    }
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', state.theme === 'dark');
    localStorage.setItem('akkula_theme', state.theme);
  }, [state.theme]);

  const isAdmin = useCallback(() => {
    return state.user?.email === ADMIN_EMAIL && state.user?.role === 'admin';
  }, [state.user]);

  const login = useCallback(async (email: string, password: string) => {
    await new Promise(r => setTimeout(r, 800));
    
    if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
      const adminUser: User = {
        id: 'admin-001',
        name: 'Admin',
        email: ADMIN_EMAIL,
        avatar: '👑',
        level: 6,
        xp: 99999,
        streak: 365,
        lessonsCompleted: [],
        achievements: ['first_lesson', 'week_streak', 'vocab_master', 'grammar_pro', 'top_student', 'ai_friend'],
        isPremium: true,
        role: 'admin',
        joinedAt: '2024-01-01',
        lastActive: new Date().toISOString(),
        dailyMinutes: 0,
        banned: false,
      };
      const users = getStoredUsers();
      if (!users.find(u => u.id === adminUser.id)) {
        users.push(adminUser);
        saveUsers(users);
      }
      localStorage.setItem('akkula_current_user', JSON.stringify(adminUser));
      setState(s => ({ ...s, user: adminUser, isAuthenticated: true }));
      return { success: true };
    }

    const users = getStoredUsers();
    const user = users.find(u => u.email === email);
    if (!user) return { success: false, error: 'User not found' };
    if (user.banned) return { success: false, error: 'Account is banned' };
    
    user.lastActive = new Date().toISOString();
    saveUsers(users);
    localStorage.setItem('akkula_current_user', JSON.stringify(user));
    setState(s => ({ ...s, user, isAuthenticated: true }));
    return { success: true };
  }, []);

  const register = useCallback(async (name: string, email: string, password: string) => {
    await new Promise(r => setTimeout(r, 800));
    const users = getStoredUsers();
    if (users.find(u => u.email === email)) return { success: false, error: 'Email already exists' };
    
    const avatars = ['🦊', '🐱', '🐶', '🐼', '🦁', '🐸', '🦋', '🌟', '🎯', '🚀'];
    const newUser: User = {
      id: `user-${Date.now()}`,
      name,
      email,
      avatar: avatars[Math.floor(Math.random() * avatars.length)],
      level: 1,
      xp: 0,
      streak: 0,
      lessonsCompleted: [],
      achievements: [],
      isPremium: false,
      role: 'user',
      joinedAt: new Date().toISOString(),
      lastActive: new Date().toISOString(),
      dailyMinutes: 0,
      banned: false,
    };
    users.push(newUser);
    saveUsers(users);
    localStorage.setItem('akkula_current_user', JSON.stringify(newUser));
    setState(s => ({ ...s, user: newUser, isAuthenticated: true }));
    return { success: true };
  }, []);

  const loginWithGoogle = useCallback(async () => {
    await new Promise(r => setTimeout(r, 1000));
    const name = 'Google User';
    const email = `user${Date.now()}@gmail.com`;
    return register(name, email, 'google-auth');
  }, [register]);

  const logout = useCallback(() => {
    localStorage.removeItem('akkula_current_user');
    setState(s => ({ ...s, user: null, isAuthenticated: false }));
  }, []);

  const resetPassword = useCallback(async (email: string) => {
    await new Promise(r => setTimeout(r, 800));
    const users = getStoredUsers();
    if (!users.find(u => u.email === email)) return { success: false, error: 'Email not found' };
    return { success: true };
  }, []);

  const toggleTheme = useCallback(() => {
    setState(s => ({ ...s, theme: s.theme === 'light' ? 'dark' : 'light' }));
  }, []);

  const toggleSidebar = useCallback(() => {
    setState(s => ({ ...s, sidebarOpen: !s.sidebarOpen }));
  }, []);

  const toggleAiChat = useCallback(() => {
    setState(s => ({ ...s, aiChatOpen: !s.aiChatOpen }));
  }, []);

  const updateProfile = useCallback((data: Partial<User>) => {
    setState(s => {
      if (!s.user) return s;
      const updated = { ...s.user, ...data };
      const users = getStoredUsers().map(u => u.id === updated.id ? updated : u);
      saveUsers(users);
      localStorage.setItem('akkula_current_user', JSON.stringify(updated));
      return { ...s, user: updated };
    });
  }, []);

  const addXP = useCallback((amount: number) => {
    setState(s => {
      if (!s.user) return s;
      const newXp = s.user.xp + amount;
      const newLevel = Math.min(6, Math.floor(newXp / 500) + 1);
      const updated = { ...s.user, xp: newXp, level: newLevel, lastActive: new Date().toISOString() };
      const users = getStoredUsers().map(u => u.id === updated.id ? updated : u);
      saveUsers(users);
      localStorage.setItem('akkula_current_user', JSON.stringify(updated));
      return { ...s, user: updated };
    });
  }, []);

  const completeLesson = useCallback((lessonId: string) => {
    setState(s => {
      if (!s.user || s.user.lessonsCompleted.includes(lessonId)) return s;
      const updated = {
        ...s.user,
        lessonsCompleted: [...s.user.lessonsCompleted, lessonId],
        xp: s.user.xp + 50,
        level: Math.min(6, Math.floor((s.user.xp + 50) / 500) + 1),
        lastActive: new Date().toISOString(),
      };
      const users = getStoredUsers().map(u => u.id === updated.id ? updated : u);
      saveUsers(users);
      localStorage.setItem('akkula_current_user', JSON.stringify(updated));
      return { ...s, user: updated };
    });
  }, []);

  const unlockAchievement = useCallback((id: string) => {
    setState(s => {
      if (!s.user || s.user.achievements.includes(id)) return s;
      const updated = { ...s.user, achievements: [...s.user.achievements, id] };
      const users = getStoredUsers().map(u => u.id === updated.id ? updated : u);
      saveUsers(users);
      localStorage.setItem('akkula_current_user', JSON.stringify(updated));
      return { ...s, user: updated };
    });
  }, []);

  const getAllUsers = useCallback(() => getStoredUsers(), []);

  const banUser = useCallback((userId: string) => {
    const users = getStoredUsers().map(u => u.id === userId ? { ...u, banned: true } : u);
    saveUsers(users);
    setState(s => {
      if (s.user?.id === userId) {
        localStorage.removeItem('akkula_current_user');
        return { ...s, user: null, isAuthenticated: false };
      }
      return s;
    });
  }, []);

  const unbanUser = useCallback((userId: string) => {
    const users = getStoredUsers().map(u => u.id === userId ? { ...u, banned: false } : u);
    saveUsers(users);
  }, []);

  const updateStreak = useCallback(() => {
    setState(s => {
      if (!s.user) return s;
      const lastDate = new Date(s.user.lastActive);
      const now = new Date();
      const diffDays = Math.floor((now.getTime() - lastDate.getTime()) / 86400000);
      let newStreak = s.user.streak;
      if (diffDays === 1) newStreak += 1;
      else if (diffDays > 1) newStreak = 1;
      const updated = { ...s.user, streak: newStreak, lastActive: now.toISOString() };
      const users = getStoredUsers().map(u => u.id === updated.id ? updated : u);
      saveUsers(users);
      localStorage.setItem('akkula_current_user', JSON.stringify(updated));
      return { ...s, user: updated };
    });
  }, []);

  return (
    <AppContext.Provider value={{
      state, login, register, loginWithGoogle, logout, resetPassword,
      toggleTheme, toggleSidebar, toggleAiChat, updateProfile,
      addXP, completeLesson, unlockAchievement, isAdmin, getAllUsers,
      banUser, unbanUser, updateStreak,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
