interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

const grammarExplanations: Record<string, Record<string, string>> = {
  en: {
    'present simple': "The Present Simple tense is used for habits, routines, and general truths.\n\n**Structure:** Subject + V1 (V+s/es for he/she/it)\n\n**Examples:**\n• I work every day.\n• She speaks English fluently.\n• Water boils at 100°C.\n\n**Negative:** Subject + don't/doesn't + V1\n**Question:** Do/Does + Subject + V1?",
    'past simple': "The Past Simple tense describes completed actions in the past.\n\n**Structure:** Subject + V2 (regular: -ed)\n\n**Examples:**\n• I visited London last year.\n• She studied hard for the exam.\n• They didn't go to school.\n\n**Negative:** Subject + didn't + V1\n**Question:** Did + Subject + V1?",
    'present perfect': "The Present Perfect connects past to present.\n\n**Structure:** Subject + have/has + V3\n\n**Examples:**\n• I have lived here for 5 years.\n• She has just finished her homework.\n• Have you ever been to Paris?\n\nUse 'for' with duration, 'since' with a point in time.",
    'future simple': "The Future Simple tense is used for predictions, promises, and spontaneous decisions.\n\n**Structure:** Subject + will + V1\n\n**Examples:**\n• I will help you tomorrow.\n• It will rain next week.\n• I'll call you later.\n\n**Negative:** Subject + won't + V1\n**Question:** Will + Subject + V1?",
    'conditionals': "Conditional sentences express hypothetical situations.\n\n**Zero:** If + present, present (general truths)\n**First:** If + present, will + V1 (real future)\n**Second:** If + past, would + V1 (unreal present)\n**Third:** If + past perfect, would have + V3 (unreal past)\n\n**Examples:**\n• If it rains, I stay home. (Zero)\n• If I study, I will pass. (First)\n• If I were rich, I would travel. (Second)\n• If I had known, I would have helped. (Third)",
    'articles': "English has three articles: a, an, the.\n\n**A/An** (Indefinite):\n• 'a' before consonant sounds: a book, a university\n• 'an' before vowel sounds: an apple, an hour\n\n**The** (Definite):\n• Specific items: The sun is bright.\n• Already mentioned: I saw a dog. The dog was brown.\n\n**No Article:**\n• General plural/uncountable: I love music.",
    'passive voice': "The Passive Voice focuses on the action, not who performs it.\n\n**Structure:** Subject + be + V3\n\n**Examples:**\n• Active: She wrote the letter.\n• Passive: The letter was written by her.\n\n**Tenses:**\n• Present: is/are + V3\n• Past: was/were + V3\n• Future: will be + V3\n• Perfect: has/have been + V3",
    'modal verbs': "Modal verbs express ability, possibility, permission, or obligation.\n\n**Can/Could:** ability, possibility\n• I can swim. Could you help me?\n\n**Must/Have to:** obligation\n• You must wear a seatbelt.\n\n**Should:** advice\n• You should exercise daily.\n\n**May/Might:** possibility\n• It may rain tomorrow.\n\nModals are followed by the base form (V1).",
  },
  ru: {
    'present simple': "Present Simple используется для привычек, рутины и общих истин.\n\n**Структура:** Подлежащее + V1 (V+s/es для he/she/it)\n\n**Примеры:**\n• I work every day. (Я работаю каждый день)\n• She speaks English. (Она говорит по-английски)\n\n**Отрицание:** don't/doesn't + V1\n**Вопрос:** Do/Does + подлежащее + V1?",
    'present perfect': "Present Perfect связывает прошлое с настоящим.\n\n**Структура:** have/has + V3 (третья форма глагола)\n\n**Примеры:**\n• I have lived here for 5 years. (Я живу здесь 5 лет)\n• She has just finished. (Она только что закончила)\n\nИспользуйте 'for' с периодом времени, 'since' с точкой во времени.",
    'past simple': "Past Simple описывает завершенные действия в прошлом.\n\n**Структура:** Подлежащее + V2 (правильные: -ed)\n\n**Примеры:**\n• I visited London last year.\n• She studied hard.\n\n**Отрицание:** didn't + V1\n**Вопрос:** Did + подлежащее + V1?",
  },
  ky: {
    'present simple': "Present Simple чакты адаттар, рутиндер жана жалпы чындыктар ѳчүн колдонулат.\n\n**Структурасы:** Башкы сѳз + V1 (he/she/it ѳчүн V+s/es)\n\n**Мисалдар:**\n• I work every day. (Мен күн сайын иштейм)\n• She speaks English. (Ал англисче сүйлѳйт)\n\n**Терс:** don't/doesn't + V1\n**Суроо:** Do/Does + башкы сѳз + V1?",
    'present perfect': "Present Perfect ѳткѳндү учурга байланыштырат.\n\n**Структурасы:** have/has + V3\n\n**Мисалдар:**\n• I have lived here for 5 years. (Мен бул жерде 5 жылдан бери жашайм)\n\n'for' мѳѳнѳт менен, 'since' белгилүү убакыт менен колдонулат.",
  },
};

const vocabDatabase: Record<string, Record<string, string>> = {
  'serendipity': { en: 'The occurrence of events by chance in a happy way.\n\nExample: Finding this book was pure serendipity.\n\nSynonyms: luck, chance, fortune', ru: 'Счастливая случайность.\n\nПример: Найти эту книгу было чистой серенди́пностью.\n\nСинонимы: удача, случайность', ky: 'Бактылуу кокустук.\n\nМисал: Бул китепти табуу таза серенди́пность болду.' },
  'eloquent': { en: 'Fluent or persuasive in speaking or writing.\n\nExample: She gave an eloquent speech about education.\n\nSynonyms: articulate, expressive, persuasive', ru: 'Красноречивый, убедительный.\n\nПример: Она произнесла красноречивую речь.\n\nСинонимы: красноречивый, выразительный', ky: 'Кѳркѳм сүйлѳгѳн, ишендирүүчү.\n\nМисал: Ал билим жѳнүндѳ кѳркѳм сѳз сүйлѳдү.' },
  'ubiquitous': { en: 'Present, appearing, or found everywhere.\n\nExample: Mobile phones are ubiquitous in modern life.\n\nSynonyms: omnipresent, pervasive, widespread', ru: 'Вездесущий, повсеместный.\n\nПример: Мобильные телефоны повсеместны.\n\nСинонимы: вездесущий, повсеместный', ky: 'Бардык жерде бар.\n\nМисал: Мобилдик телефондор заманбап жашоодо бардык жерде бар.' },
  'resilient': { en: 'Able to recover quickly from difficulties.\n\nExample: Children are remarkably resilient.\n\nSynonyms: tough, adaptable, strong', ru: 'Стойкий, устойчивый.\n\nПример: Дети удивительно стойкие.\n\nСинонимы: стойкий, крепкий', ky: 'Тез калыбына келүүчү.\n\nМисал: Балдар абдан чыдамдуу.' },
  'ephemeral': { en: 'Lasting for a very short time.\n\nExample: The beauty of cherry blossoms is ephemeral.\n\nSynonyms: fleeting, transient, brief', ru: 'Быстротечный, скоропреходящий.\n\nПример: Красота цветущей вишни быстротечна.\n\nСинонимы: мимолётный, кратковременный', ky: 'Кыска мѳѳнѳттүү.\n\nМисал: Алча гүлдѳрүнүн сулуулугу кыска мѳѳнѳттүү.' },
};

function detectLanguage(text: string): 'en' | 'ru' | 'ky' {
  const kyrgyzWords = ['эмне', 'кантип', 'жѳнүндѳ', 'учун', 'менен', 'бул', 'андан', 'деген', 'болот', 'керек'];
  const russianWords = ['что', 'как', 'это', 'какой', 'почему', 'который', 'можно', 'нужно', 'какой', 'когда'];
  const lower = text.toLowerCase();
  if (kyrgyzWords.some(w => lower.includes(w))) return 'ky';
  if (russianWords.some(w => lower.includes(w))) return 'ru';
  if (/[а-яА-ЯёЁ]/.test(text)) {
    if (/[ңоөүӊ]/i.test(text)) return 'ky';
    return 'ru';
  }
  return 'en';
}

function findGrammarTopic(text: string): string | null {
  const lower = text.toLowerCase();
  const topics = ['present simple', 'past simple', 'present perfect', 'future simple', 'conditionals', 'articles', 'passive voice', 'modal verbs', 'relative clauses', 'reported speech'];
  for (const topic of topics) {
    if (lower.includes(topic)) return topic;
  }
  if (lower.includes('tense') || lower.includes('времен') || lower.includes('чактар') || lower.includes('present') || lower.includes('perfect')) {
    if (lower.includes('present') && lower.includes('perfect')) return 'present perfect';
    if (lower.includes('present')) return 'present simple';
    if (lower.includes('past')) return 'past simple';
    if (lower.includes('future')) return 'future simple';
  }
  if (lower.includes('modal')) return 'modal verbs';
  if (lower.includes('passive')) return 'passive voice';
  if (lower.includes('article') || lower.includes('артикл')) return 'articles';
  if (lower.includes('conditional') || lower.includes('шарт')) return 'conditionals';
  return null;
}

function findVocabWord(text: string): string | null {
  const lower = text.toLowerCase();
  const words = Object.keys(vocabDatabase);
  for (const word of words) {
    if (lower.includes(word)) return word;
  }
  return null;
}

function generateCorrection(text: string, lang: string): string {
  const corrections: Record<string, string> = {
    en: `Here's my feedback on your text:\n\n📝 **Original:** "${text}"\n\n✅ **Corrections:**\n• Check subject-verb agreement\n• Ensure correct tense usage\n• Review article usage (a/an/the)\n\n💡 **Tip:** Read your text aloud to catch errors naturally.\n\nWould you like me to explain any specific grammar rule?`,
    ru: `Вот мой отзыв о вашем тексте:\n\n📝 **Оригинал:** "${text}"\n\n✅ **Исправления:**\n• Проверьте согласование подлежащего и глагола\n• Убедитесь в правильности времён\n• Проверьте использование артиклей\n\n💡 **Совет:** Прочтите текст вслух, чтобы заметить ошибки.\n\nХотите, чтобы я объяснил какое-то правило?`,
    ky: `Сиздин текст жѳнүндѳ менин пикирим:\n\n📝 **Оригинал:** "${text}"\n\n✅ **Ѳзгѳртүүлѳр:**\n• Башкы сѳз менен этишти текшериңиз\n• Чактардын тууралыгын текшериңиз\n• Артикльдерди текшериңиз\n\n💡 **Кеңеш:** Текстти катуу окуп чыгыңыз.\n\nѲзгѳчѳ кайсы эрежени түшүндүрүүмдү каалайсызбы?`,
  };
  return corrections[lang] || corrections.en;
}

export async function getAIResponse(messages: ChatMessage[]): Promise<string> {
  await new Promise(r => setTimeout(r, 600 + Math.random() * 800));
  
  const lastMsg = messages[messages.length - 1];
  if (!lastMsg || lastMsg.role !== 'user') return 'How can I help you?';
  
  const text = lastMsg.content;
  const lang = detectLanguage(text);
  const lower = text.toLowerCase();
  
  // Check for grammar explanation request
  const topic = findGrammarTopic(text);
  if (topic) {
    const explanation = grammarExplanations[lang]?.[topic] || grammarExplanations.en[topic];
    if (explanation) return explanation;
  }
  
  // Check for vocabulary explanation
  const vocabWord = findVocabWord(text);
  if (vocabWord) {
    const data = vocabDatabase[vocabWord];
    return data[lang] || data.en;
  }
  
  // Translation request
  if (lower.includes('translate') || lower.includes('котор') || lower.includes(' котор')) {
    if (lang === 'ky') {
      return "Мен сѳздѳрдү жана сѳз айкаштарын которо алам. Кандай сѳздү же сүйлѳмдү которууну каалайсыз?\n\nМисалы:\n• \"serendipity деген эмне?\"\n• \"Translate 'happy' to Kyrgyz\"";
    }
    if (lang === 'ru') {
      return "Я могу переводить слова и фразы. Какое слово или предложение вы хотите перевести?\n\nНапример:\n• \"Что такое 'serendipity'?\"\n• \"Переведи 'happy' на русский\"";
    }
    return "I can translate words and phrases for you! What would you like me to translate?\n\nFor example:\n• \"What does 'serendipity' mean?\"\n• \"Translate 'happy' to Russian\"";
  }
  
  // Greeting
  if (lower.match(/^(hi|hello|hey|привет|салам|саламатсыз)/)) {
    const greetings: Record<string, string> = {
      en: "Hello! 👋 I'm your AI English tutor. I can help you with:\n\n📚 **Grammar** - Ask about any tense or rule\n📖 **Vocabulary** - Learn new words\n✍️ **Corrections** - Submit text for feedback\n🌍 **Translation** - Translate words and phrases\n\nWhat would you like to learn today?",
      ru: "Здравствуйте! 👋 Я ваш ИИ-репетитор английского. Я могу помочь с:\n\n📚 **Грамматика** - Спросите о любом времени или правиле\n📖 **Словарь** - Изучайте новые слова\n✍️ **Исправления** - Отправьте текст для проверки\n🌍 **Перевод** - Переводите слова и фразы\n\nЧему хотите научиться сегодня?",
      ky: "Саламатсызбы! 👋 Мен сиздин англис тили ИИ мугалимиңизмин. Мен жардам бере алам:\n\n📚 **Грамматика** - Кандай чак же эреже жѳнүндѳ сураңыз\n📖 **Сѳздүк** - Жаңы сѳздѳрдү үйрѳнүңүз\n✍️ **Ѳзгѳртүүлѳр** - Тексти текшерүүгѳ жѳнѳтүңүз\n🌍 **Которуу** - Сѳздѳрдү которуңуз\n\nБүгүн эмнени үйрѳнгүңүз келет?",
    };
    return greetings[lang];
  }
  
  // Help/practice request
  if (lower.includes('help') || lower.includes('помощ') || lower.includes('жардам')) {
    const helpTexts: Record<string, string> = {
      en: "I'm here to help! Here are some things you can try:\n\n1️⃣ \"Explain Present Perfect\" - Grammar explanations\n2️⃣ \"What does 'eloquent' mean?\" - Vocabulary\n3️⃣ \"Translate 'beautiful' to Russian\" - Translation\n4️⃣ \"Correct: I goes to school yesterday\" - Error correction\n5️⃣ \"Give me practice sentences\" - Practice exercises\n\nJust type your question!",
      ru: "Я готов помочь! Вот что вы можете попробовать:\n\n1️⃣ \"Объясни Present Perfect\" - Объяснение грамматики\n2️⃣ \"Что значит 'eloquent'?\" - Словарь\n3️⃣ \"Переведи 'beautiful' на русский\" - Перевод\n4️⃣ \"Проверь: I goes to school\" - Исправление ошибок\n5️⃣ \"Дай примеры для практики\" - Упражнения\n\nПросто напишите ваш вопрос!",
      ky: "Мен жардам берүүгѳ даярмын! Мисалдар:\n\n1️⃣ \"Present Perfect деген эмне?\" - Грамматика\n2️⃣ \"'Eloquent' деген эмне?\" - Сѳздүк\n3️⃣ \"'Beautiful' которчу\" - Которуу\n4️⃣ \"Текшер: I goes to school\" - Ката текшерүү\n5️⃣ \"Мага жаттыгууларды бер\" - Практика\n\nСурооңузду жазыңыз!",
    };
    return helpTexts[lang];
  }
  
  // Practice request
  if (lower.includes('practice') || lower.includes('exercise') || lower.includes('жаттыгу') || lower.includes('практик') || lower.includes('упражн')) {
    const practices: Record<string, string> = {
      en: "Here are some practice exercises for you! 🎯\n\n**Fill in the blanks:**\n\n1. She ___ (go) to school every day.\n2. They ___ (not/eat) breakfast yet.\n3. I ___ (study) English for two years.\n4. If I ___ (be) rich, I would travel.\n5. The book ___ (write) by a famous author.\n\nTry answering these and I'll check them for you! Just type your answers.",
      ru: "Вот упражнения для практики! 🎯\n\n**Вставьте пропущенное:**\n\n1. She ___ (go) to school every day.\n2. They ___ (not/eat) breakfast yet.\n3. I ___ (study) English for two years.\n4. If I ___ (be) rich, I would travel.\n5. The book ___ (write) by a famous author.\n\nПопробуйте ответить, и я проверю! Просто напишите ваши ответы.",
      ky: "Практика жаттыгуулары! 🎯\n\n**Бош жерлерди толтуруңуз:**\n\n1. She ___ (go) to school every day.\n2. They ___ (not/eat) breakfast yet.\n3. I ___ (study) English for two years.\n4. If I ___ (be) rich, I would travel.\n5. The book ___ (write) by a famous author.\n\nЖоопторуңузду жазыңыз, мен текшерип берем!",
    };
    return practices[lang];
  }
  
  // Correction request
  if (lower.includes('correct') || lower.includes('check') || lower.includes('исправ') || lower.includes('текшер') || lower.includes('провер')) {
    const textToCorrect = text.replace(/^(correct|check|исправь|текшер|проверь)[:\s]*/i, '').trim();
    if (textToCorrect.length > 5) {
      return generateCorrection(textToCorrect, lang);
    }
  }
  
  // Default response
  const defaults: Record<string, string> = {
    en: "That's a great question! 🤔 Let me help you with that.\n\nI can assist you with:\n• **Grammar rules** and explanations\n• **Vocabulary** definitions and examples\n• **Translations** between languages\n• **Text correction** and feedback\n• **Practice exercises**\n\nCould you be more specific about what you'd like to learn? For example, try asking:\n\"Explain Present Perfect tense\"\n\"What does 'eloquent' mean?\"",
    ru: "Отличный вопрос! 🤔 Давайте разберёмся.\n\nЯ могу помочь с:\n• **Грамматика** и объяснения правил\n• **Словарь** - определения и примеры\n• **Перевод** между языками\n• **Исправление текста**\n• **Упражнения** для практики\n\nМожете уточнить, что именно вы хотите узнать? Например:\n\"Объясни Present Perfect\"\n\"Что значит 'eloquent'?\"",
    ky: "Жакшы суроо! 🤔 Кѳрѳлү.\n\nМен жардам бере алам:\n• **Грамматика** эрежелери\n• **Сѳздүк** - аныктамалар\n• **Которуу** тилдер арасында\n• **Текстти тууралоо**\n• **Жаттыгуулар**\n\nѲзгѳчѳ эмнени үйрѳнгүңүз келет? Мисалы:\n\"Present Perfect деген эмне?\"\n\"'Eloquent' деген эмне?\"",
  };
  return defaults[lang];
}
