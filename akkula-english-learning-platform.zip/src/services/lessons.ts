export interface Question {
  id: string;
  type: 'multiple-choice' | 'fill-blank' | 'match' | 'true-false';
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
}

export interface Lesson {
  id: string;
  title: string;
  titleRu: string;
  titleKy: string;
  description: string;
  descriptionRu: string;
  descriptionKy: string;
  level: number;
  type: 'reading' | 'grammar' | 'vocabulary' | 'listening' | 'speaking' | 'writing' | 'quiz';
  duration: number;
  xp: number;
  isPremium: boolean;
  questions: Question[];
  content: string;
  contentRu: string;
  contentKy: string;
}

export const courses = [
  { id: 'c1', level: 1, titleEn: 'Beginner English', titleRu: 'Английский для начинающих', titleKy: 'Баштапкы англис тили', descriptionEn: 'Start your English journey with basics', descriptionRu: 'Начните свой путь в английском с основ', descriptionKy: 'Англис тилин негиздеринен баштаңыз', color: 'from-green-400 to-emerald-600', icon: '🌱', students: 12500, lessons: 24, progress: 0 },
  { id: 'c2', level: 2, titleEn: 'Elementary English', titleRu: 'Элементарный английский', titleKy: 'Элементардык англис тили', descriptionEn: 'Build on your basic knowledge', descriptionRu: 'Развивайте базовые знания', descriptionKy: 'Негизги билимиңизди ѳстүрүңүз', color: 'from-blue-400 to-indigo-600', icon: '📚', students: 9800, lessons: 28, progress: 0 },
  { id: 'c3', level: 3, titleEn: 'Pre-Intermediate', titleRu: 'Ниже среднего', titleKy: 'Ортодон тѳмѳн', descriptionEn: 'Take your skills to the next level', descriptionRu: 'Поднимите навыки на следующий уровень', descriptionKy: 'Кѳндүмдѳрүңүздү кийинки деңгээлге кѳтѳрүңүз', color: 'from-purple-400 to-violet-600', icon: '🎯', students: 7200, lessons: 32, progress: 0 },
  { id: 'c4', level: 4, titleEn: 'Intermediate English', titleRu: 'Средний уровень', titleKy: 'Орто деңгээл', descriptionEn: 'Master everyday communication', descriptionRu: 'Освойте повседневное общение', descriptionKy: 'Күнүмдүк баарлашууну ѳздѳштүрүңүз', color: 'from-orange-400 to-red-500', icon: '💡', students: 5400, lessons: 36, progress: 0 },
  { id: 'c5', level: 5, titleEn: 'Upper Intermediate', titleRu: 'Выше среднего', titleKy: 'Ортодон жогору', descriptionEn: 'Refine and polish your English', descriptionRu: 'Усовершенствуйте ваш английский', descriptionKy: 'Англис тилиңизди жетилтириңиз', color: 'from-pink-400 to-rose-600', icon: '🔥', students: 3100, lessons: 40, progress: 0 },
  { id: 'c6', level: 6, titleEn: 'Advanced English', titleRu: 'Продвинутый английский', titleKy: 'Ѳнүккѳн англис тили', descriptionEn: 'Achieve fluency and confidence', descriptionRu: 'Достигните свободного владения', descriptionKy: 'Эркин сүйлѳѳгѳ жетиңизз', color: 'from-amber-400 to-yellow-600', icon: '🏆', students: 1800, lessons: 44, progress: 0 },
];

export const lessons: Lesson[] = [
  {
    id: 'l1', title: 'Greetings & Introductions', titleRu: 'Приветствия', titleKy: 'Саламдашуулар',
    description: 'Learn how to greet people and introduce yourself', descriptionRu: 'Научитесь приветствовать и представляться', descriptionKy: 'Адамдарды саламдап, ѳзүңүздү тааныштырууну үйрѳнүңүз',
    level: 1, type: 'vocabulary', duration: 15, xp: 50, isPremium: false,
    content: "Hello! Welcome to your first English lesson.\n\nIn English, we use different greetings depending on the time and situation:\n\n**Formal:**\n- Good morning (before 12 PM)\n- Good afternoon (12 PM - 6 PM)\n- Good evening (after 6 PM)\n\n**Informal:**\n- Hi / Hey\n- What's up?\n- How's it going?\n\n**Introducing yourself:**\n- My name is...\n- I'm from...\n- Nice to meet you!",
    contentRu: "Здравствуйте! Добро пожаловать на ваш первый урок английского.\n\nВ английском мы используем разные приветствия в зависимости от времени:\n\n**Формальные:**\n- Good morning (до 12:00)\n- Good afternoon (12:00 - 18:00)\n- Good evening (после 18:00)\n\n**Неформальные:**\n- Hi / Hey\n- What's up?\n- How's it going?\n\n**Представление:**\n- My name is...\n- I'm from...\n- Nice to meet you!",
    contentKy: "Саламатсызбы! англис тилиндеги биринчи сабагыңызга кош келиңиз.\n\nАнглис тилинде ар кандай саламдашууларды колдонобуз:\n\n**Расмий:**\n- Good morning (12:00 чейин)\n- Good afternoon (12:00 - 18:00)\n- Good evening (18:00дон кийин)\n\n**Расмий эмес:**\n- Hi / Hey\n- What's up?\n- How's it going?\n\n**Ѳзүңүздү тааныштыруу:**\n- My name is...\n- I'm from...\n- Nice to meet you!",
    questions: [
      { id: 'q1', type: 'multiple-choice', question: 'Which greeting is used in the morning?', options: ['Good evening', 'Good morning', 'Good night', 'Good afternoon'], correctAnswer: 'Good morning', explanation: 'Good morning is used before 12 PM.' },
      { id: 'q2', type: 'multiple-choice', question: '"Nice to meet you" is used when:', options: ['Saying goodbye', 'Meeting someone new', 'Ordering food', 'Asking for directions'], correctAnswer: 'Meeting someone new', explanation: 'We say "Nice to meet you" when meeting someone for the first time.' },
      { id: 'q3', type: 'fill-blank', question: 'My ___ is John.', correctAnswer: 'name', explanation: 'The complete sentence is "My name is John."' },
      { id: 'q4', type: 'true-false', question: '"What\'s up?" is a formal greeting.', options: ['True', 'False'], correctAnswer: 'False', explanation: '"What\'s up?" is informal/casual.' },
    ],
  },
  {
    id: 'l2', title: 'Present Simple Tense', titleRu: 'Настоящее простое время', titleKy: 'Present Simple чак',
    description: 'Master the Present Simple tense', descriptionRu: 'Освойте настоящее простое время', descriptionKy: 'Present Simple чакты ѳздѳштүрүңүз',
    level: 1, type: 'grammar', duration: 20, xp: 75, isPremium: false,
    content: "**Present Simple** is the most basic English tense.\n\n**When to use:**\n• Habits and routines: I drink coffee every morning.\n• Facts: The sun rises in the east.\n• Permanent states: She lives in London.\n\n**Structure:**\n• Affirmative: Subject + V1 (I/you/we/they) or V1+s/es (he/she/it)\n• Negative: Subject + don't/doesn't + V1\n• Question: Do/Does + Subject + V1?\n\n**Spelling rules for -es:**\n• Verbs ending in -sh, -ch, -x, -o → add -es (watches, goes)\n• Verbs ending in consonant + y → change y to -ies (study → studies)",
    contentRu: "**Present Simple** — самое базовое время в английском.\n\n**Когда использовать:**\n• Привычки: I drink coffee every morning.\n• Факты: The sun rises in the east.\n• Постоянные состояния: She lives in London.\n\n**Структура:**\n• Утверждение: Подлежащее + V1\n• Отрицание: don't/doesn't + V1\n• Вопрос: Do/Does + подлежащее + V1?",
    contentKy: "**Present Simple** — англис тилиндеги эӊ негизги чак.\n\n**Качан колдонулат:**\n• Адаттар: I drink coffee every morning.\n• Фактылар: The sun rises in the east.\n•Ѳӊдѳмѳ абалдар: She lives in London.",
    questions: [
      { id: 'q1', type: 'multiple-choice', question: 'She ___ to school every day.', options: ['go', 'goes', 'going', 'went'], correctAnswer: 'goes', explanation: 'Third person singular (she) requires -es: goes.' },
      { id: 'q2', type: 'fill-blank', question: 'They ___ (not/like) coffee.', correctAnswer: "don't like", explanation: 'They + don\'t + base form = don\'t like' },
      { id: 'q3', type: 'multiple-choice', question: '___ she speak English?', options: ['Do', 'Does', 'Is', 'Are'], correctAnswer: 'Does', explanation: 'Does is used for questions with he/she/it.' },
      { id: 'q4', type: 'true-false', question: 'Present Simple is used for future planned events.', options: ['True', 'False'], correctAnswer: 'False', explanation: 'Present Simple is for habits, facts, and routines, not future events.' },
    ],
  },
  {
    id: 'l3', title: 'Family & Relationships', titleRu: 'Семья и отношения', titleKy: 'Ѳбѳлѳ жана мамилелер',
    description: 'Learn vocabulary about family members', descriptionRu: 'Изучите словарь членов семьи', descriptionKy: 'Ѳбѳлѳ мүчѳлѳрү жѳнүндѳ сѳздѳрдү үйрѳнүңүз',
    level: 1, type: 'vocabulary', duration: 15, xp: 50, isPremium: false,
    content: "Let's learn family vocabulary!\n\n**Immediate family:**\n• Mother (Mom) — эне/мама\n• Father (Dad) — ата/папа\n• Sister — эже/карындаш\n• Brother — бир тууган\n• Son — уул\n• Daughter — кыз\n\n**Extended family:**\n• Grandmother — чоң эне\n• Grandfather — чоң ата\n• Uncle — таяке/эже\n• Aunt — эже/таяке\n• Cousin — таяке бала\n\n**Possessive forms:**\n• My mother's house\n• My parents' car",
    contentRu: "Изучаем словарь семьи!\n\n**Близкие родственники:**\n• Mother (Mom) — мама\n• Father (Dad) — папа\n• Sister — сестра\n• Brother — брат\n• Son — сын\n• Daughter — дочь\n\n**Расширенная семья:**\n• Grandmother — бабушка\n• Grandfather — дедушка\n• Uncle — дядя\n• Aunt — тётя\n• Cousin — двоюродный брат/сестра",
    contentKy: "Ѳбѳлѳ сѳздүгүн үйрѳнѳлү!\n\n**Жакын туугандар:**\n• Mother (Mom) — эне\n• Father (Dad) — ата\n• Sister — эже/карындаш\n• Brother — бир тууган\n• Son — уул\n• Daughter — кыз",
    questions: [
      { id: 'q1', type: 'multiple-choice', question: "Your mother's mother is your:", options: ['Aunt', 'Grandmother', 'Sister', 'Cousin'], correctAnswer: 'Grandmother', explanation: 'Your mother\'s mother is your grandmother.' },
      { id: 'q2', type: 'fill-blank', question: 'My father\'s brother is my ___.', correctAnswer: 'uncle', explanation: 'Father\'s brother = uncle' },
      { id: 'q3', type: 'multiple-choice', question: 'Which is the correct possessive form?', options: ['My mothers house', "My mother's house", 'My mothers\' house', 'My mother house'], correctAnswer: "My mother's house", explanation: 'Singular possessive uses apostrophe + s.' },
    ],
  },
  {
    id: 'l4', title: 'Past Simple Tense', titleRu: 'Прошедшее простое время', titleKy: 'Past Simple чак',
    description: 'Learn to talk about the past', descriptionRu: 'Научитесь говорить о прошлом', descriptionKy: 'Ѳткѳндѳ жѳнүндѳ сүйлѳѳнү үйрѳнүңүз',
    level: 2, type: 'grammar', duration: 25, xp: 75, isPremium: false,
    content: "**Past Simple** describes completed actions.\n\n**Regular verbs:** Add -ed\n• work → worked\n• play → played\n• study → studied\n\n**Irregular verbs:** Must memorize\n• go → went\n• see → saw\n• eat → ate\n• come → came\n\n**Structure:**\n• Affirmative: Subject + V2\n• Negative: Subject + didn't + V1\n• Question: Did + Subject + V1?",
    contentRu: "**Past Simple** описывает завершённые действия.\n\n**Правильные глаголы:** Добавляем -ed\n• work → worked\n• play → played\n\n**Неправильные глаголы:** Нужно запомнить\n• go → went\n• see → saw\n• eat → ate\n\n**Структура:**\n• Утверждение: Подлежащее + V2\n• Отрицание: didn't + V1\n• Вопрос: Did + подлежащее + V1?",
    contentKy: "**Past Simple** бүткѳн аракеттерди сыпаттайт.\n\n**Ѳӊдѳмѳ этиштер:** -ed кошобуз\n• work → worked\n• play → played\n\n**Ѳӊдѳмѳс этиштер:** Жаттап алуу керек\n• go → went\n• see → saw",
    questions: [
      { id: 'q1', type: 'multiple-choice', question: 'I ___ to the store yesterday.', options: ['go', 'goes', 'went', 'going'], correctAnswer: 'went', explanation: '"Yesterday" indicates past time. Go → went (irregular).' },
      { id: 'q2', type: 'fill-blank', question: 'She ___ (not/see) the movie.', correctAnswer: "didn't see", explanation: 'Negative past: didn\'t + base form.' },
      { id: 'q3', type: 'multiple-choice', question: '___ you finish your homework?', options: ['Do', 'Does', 'Did', 'Are'], correctAnswer: 'Did', explanation: 'Did is used for past simple questions.' },
    ],
  },
  {
    id: 'l5', title: 'Food & Restaurants', titleRu: 'Еда и рестораны', titleKy: 'Тамак-аш жана ресторандар',
    description: 'Order food and talk about meals', descriptionRu: 'Заказывайте еду и говорите о еде', descriptionKy: 'Тамак буйрутма берип, тамак жѳнүндѳ сүйлѳңүз',
    level: 2, type: 'vocabulary', duration: 20, xp: 60, isPremium: false,
    content: "Let's learn food vocabulary!\n\n**Meals:**\n• Breakfast — завтрак / эртеңки тамак\n• Lunch — обед / түшкү тамак\n• Dinner — ужин / кечки тамак\n\n**At a restaurant:**\n• Can I have the menu, please?\n• I would like to order...\n• Could I get the bill, please?\n• Is service charge included?\n\n**Useful adjectives:**\n• Delicious / Tasty — вкусный\n• Spicy — острый\n• Sweet — сладкий\n• Bitter — горький",
    contentRu: "Учим словарь еды!\n\n**Приёмы пищи:**\n• Breakfast — завтрак\n• Lunch — обед\n• Dinner — ужин\n\n**В ресторане:**\n• Могу я получить меню?\n• Я хотел бы заказать...\n• Счёт, пожалуйста.",
    contentKy: "Тамак-аш сѳздүгүн үйрѳнѳлү!\n\n**Тамак убакыттары:**\n• Breakfast — эртеңки тамак\n• Lunch — түшкү тамак\n• Dinner — кечки тамак",
    questions: [
      { id: 'q1', type: 'multiple-choice', question: 'Which meal do you eat in the morning?', options: ['Lunch', 'Dinner', 'Breakfast', 'Snack'], correctAnswer: 'Breakfast', explanation: 'Breakfast is the morning meal.' },
      { id: 'q2', type: 'fill-blank', question: 'Could I get the ___, please? (the bill)', correctAnswer: 'bill', explanation: '"Could I get the bill, please?" is used to ask for the check.' },
    ],
  },
  {
    id: 'l6', title: 'Present Perfect Tense', titleRu: 'Настоящее совершённое время', titleKy: 'Present Perfect чак',
    description: 'Connect past events to the present', descriptionRu: 'Свяжите прошлое с настоящим', descriptionKy: 'Ѳткѳндү учурга байланыштырыңыз',
    level: 3, type: 'grammar', duration: 30, xp: 100, isPremium: false,
    content: "**Present Perfect** connects the past to the present.\n\n**Structure:** have/has + V3 (past participle)\n\n**When to use:**\n• Experience: I have been to Paris.\n• Unfinished past: I have lived here for 5 years.\n• Recent past: She has just arrived.\n\n**Time expressions:**\n• ever/never — Have you ever...?\n• just — She has just finished.\n• already — I have already eaten.\n• yet — Have you finished yet?\n• for/since — for 5 years / since 2020\n\n**Irregular past participles:**\n• go → gone • see → seen • eat → eaten • write → written",
    contentRu: "**Present Perfect** связывает прошлое с настоящим.\n\n**Структура:** have/has + V3\n\n**Когда использовать:**\n• Опыт: I have been to Paris.\n• Незавершённое прошлое: I have lived here for 5 years.\n• Недавнее прошлое: She has just arrived.\n\n**Указатели времени:**\n• ever/never, just, already, yet, for/since",
    contentKy: "**Present Perfect** ѳткѳндү учурга байланыштырат.\n\n**Структурасы:** have/has + V3\n\n**Качан колдонулат:**\n• Тажрыйба: I have been to Paris.\n• Бүтѳ элек ѳткѳн: I have lived here for 5 years.\n• Жакында ѳткѳн: She has just arrived.",
    questions: [
      { id: 'q1', type: 'multiple-choice', question: 'I ___ (visit) London twice.', options: ['visited', 'have visited', 'visiting', 'visits'], correctAnswer: 'have visited', explanation: 'Experience in life uses Present Perfect: have + past participle.' },
      { id: 'q2', type: 'fill-blank', question: 'She has ___ arrived. (a moment ago)', correctAnswer: 'just', explanation: '"Just" is used with Present Perfect for very recent actions.' },
      { id: 'q3', type: 'multiple-choice', question: 'I have lived here ___ 2018.', options: ['for', 'since', 'from', 'ago'], correctAnswer: 'since', explanation: '"Since" is used with a specific point in time.' },
    ],
  },
  {
    id: 'l7', title: 'Travel & Directions', titleRu: 'Путешествия и направления', titleKy: 'Саякат жана багыттар',
    description: 'Navigate and discuss travel plans', descriptionRu: 'Ориентируйтесь и обсуждайте планы', descriptionKy: 'Багыт алып, саякат пландарын талкуулаңыз',
    level: 3, type: 'vocabulary', duration: 20, xp: 70, isPremium: false,
    content: "Travel vocabulary for your adventures!\n\n**Transportation:**\n• Airplane / Flight\n• Train / Platform\n• Bus / Bus stop\n• Taxi / Cab\n\n**Asking for directions:**\n• Excuse me, where is...?\n• How do I get to...?\n• Is it far from here?\n• Turn left/right\n• Go straight ahead\n\n**At the airport:**\n• Check-in / Boarding pass\n• Gate / Terminal\n• Luggage / Baggage claim\n• Departure / Arrival",
    contentRu: "Словарь путешествий!\n\n**Транспорт:**\n• Самолёт / Рейс\n• Поезд / Платформа\n• Автобус\n• Такси\n\n**Спросить дорогу:**\n• Извините, где...?\n• Как добраться до...?\n• Это далеко отсюда?",
    contentKy: "Саякат сѳздүгү!\n\n**Транспорт:**\n• Учак / Рейс\n• Поезд / Платформа\n• Автобус\n• Такси",
    questions: [
      { id: 'q1', type: 'multiple-choice', question: 'Which phrase asks for directions politely?', options: ['Where is it?!', 'Tell me the way!', 'Excuse me, where is...?', 'I need directions!'], correctAnswer: 'Excuse me, where is...?', explanation: '"Excuse me" makes the question polite.' },
      { id: 'q2', type: 'fill-blank', question: 'Go straight ___ and turn left.', correctAnswer: 'ahead', explanation: '"Go straight ahead" means to continue forward.' },
    ],
  },
  {
    id: 'l8', title: 'Conditionals', titleRu: 'Условные предложения', titleKy: 'Шарттуу сүйлѳмдѳр',
    description: 'Master all four conditional types', descriptionRu: 'Освойте все типы условных предложений', descriptionKy: 'Бардык шарттуу сүйлѳм түрлѳрүн ѳздѳштүрүңүз',
    level: 4, type: 'grammar', duration: 35, xp: 120, isPremium: false,
    content: "**Conditionals** express hypothetical situations.\n\n**Zero Conditional** (general truths):\nIf + present, present\n→ If you heat water, it boils.\n\n**First Conditional** (real future):\nIf + present, will + V1\n→ If it rains, I will stay home.\n\n**Second Conditional** (unreal present):\nIf + past, would + V1\n→ If I were rich, I would travel.\n\n**Third Conditional** (unreal past):\nIf + past perfect, would have + V3\n→ If I had studied, I would have passed.",
    contentRu: "**Условные предложения** выражают гипотетические ситуации.\n\n**Нулевое** (факты): Если нагреть воду, она закипит.\n**Первое** (реальное будущее): Если пойдёт дождь, я останусь дома.\n**Второе** (нереальное настоящее): Если бы я был богатым...\n**Третье** (нереальное прошлое): Если бы я учился...",
    contentKy: "**Шарттуу сүйлѳмдѳр** божомолдоо абалдарды билдирет.\n\n**Ѳчүнчү** (ѳткѳн): If I had studied, I would have passed.\n**Экинчи** (учур): If I were rich, I would travel.\n**Биринчи** (келечек): If it rains, I will stay home.",
    questions: [
      { id: 'q1', type: 'multiple-choice', question: 'If I ___ rich, I would buy a house.', options: ['am', 'was', 'were', 'be'], correctAnswer: 'were', explanation: 'Second conditional uses "were" for all subjects.' },
      { id: 'q2', type: 'multiple-choice', question: 'Which conditional type: "If it rains, I will stay home"?', options: ['Zero', 'First', 'Second', 'Third'], correctAnswer: 'First', explanation: 'First conditional: If + present, will + base form.' },
      { id: 'q3', type: 'fill-blank', question: 'If I had known, I ___ have helped.', correctAnswer: 'would', explanation: 'Third conditional: would have + past participle.' },
    ],
  },
  {
    id: 'l9', title: 'Business English', titleRu: 'Деловой английский', titleKy: 'Ишкерлик англис тили',
    description: 'Professional communication skills', descriptionRu: 'Навыки делового общения', descriptionKy: 'Кесиптик баарлашуу кѳндүмдѳрү',
    level: 5, type: 'vocabulary', duration: 25, xp: 90, isPremium: true,
    content: "Business English essentials!\n\n**Meetings:**\n• Let's begin the meeting.\n• I'd like to point out that...\n• Could you elaborate on that?\n• Let's move on to the next topic.\n\n**Emails:**\n• Dear Mr./Ms.,\n• I am writing to inquire about...\n• Please find attached...\n• I look forward to hearing from you.\n\n**Presentations:**\n• Today I'll be presenting...\n• As you can see from this chart...\n• In conclusion...\n• Thank you for your attention.",
    contentRu: "Основы делового английского!\n\n**Совещания:**\n• Давайте начнём совещание.\n• Я хотел бы отметить...\n• Не могли бы вы пояснить?\n\n**Электронные письма:**\n• Уважаемый...\n• Я пишу, чтобы узнать о...\n• С уважением...",
    contentKy: "Ишкерлик англис тилинин негиздери!\n\n**Жыйындар:**\n• Жыйынды баштайлы.\n• Мен белгилегим келет...\n• Түшүндүрѳ аласызбы?",
    questions: [
      { id: 'q1', type: 'multiple-choice', question: 'Which phrase starts a business email formally?', options: ['Hey!', 'Dear Mr. Smith,', 'What\'s up?', 'Hi there,'], correctAnswer: 'Dear Mr. Smith,', explanation: 'Dear Mr./Ms. is the standard formal greeting.' },
      { id: 'q2', type: 'fill-blank', question: 'I look forward to ___ from you.', correctAnswer: 'hearing', explanation: '"Look forward to" is followed by a gerund (-ing form).' },
    ],
  },
  {
    id: 'l10', title: 'Advanced Idioms', titleRu: 'Продвинутые идиомы', titleKy: 'Ѳнүккѳн идиомалар',
    description: 'Master common English idioms', descriptionRu: 'Освойте распространённые идиомы', descriptionKy: 'Кеңири таралган идиомаларды ѳздѳштүрүңүз',
    level: 6, type: 'vocabulary', duration: 30, xp: 100, isPremium: true,
    content: "English idioms to sound natural!\n\n**Common idioms:**\n• Break the ice — начать разговор\n• Hit the nail on the head — попасть в точку\n• Bite off more than you can chew — взяться за слишком много\n• A piece of cake — очень легко\n• Under the weather — болеть\n• The ball is in your court — теперь твой ход\n• Burn the midnight oil — засиживаться допоздна\n• Once in a blue moon — очень редко\n\n**Usage examples:**\n• \"The exam was a piece of cake!\" (= very easy)\n• \"I'm feeling under the weather today.\" (= slightly ill)",
    contentRu: "Английские идиомы для естественной речи!\n\n• Break the ice — начать разговор\n• Hit the nail on the head — попасть в точку\n• A piece of cake — очень легко\n• Under the weather — болеть\n• Once in a blue moon — очень редко",
    contentKy: "Табигый англис тили ѳчүн идиомалар!\n\n• Break the ice — сүйлѳмѳ баштоо\n• A piece of cake — абдан оңой\n• Under the weather — оорулуу\n• Once in a blue moon — абдан сейрек",
    questions: [
      { id: 'q1', type: 'multiple-choice', question: 'What does "a piece of cake" mean?', options: ['A dessert', 'Something very easy', 'Something expensive', 'A birthday treat'], correctAnswer: 'Something very easy', explanation: '"A piece of cake" is an idiom meaning something very easy to do.' },
      { id: 'q2', type: 'multiple-choice', question: '"Once in a blue moon" means:', options: ['Every night', 'Very often', 'Very rarely', 'During full moon'], correctAnswer: 'Very rarely', explanation: '"Once in a blue moon" means something that happens very rarely.' },
    ],
  },
];

export const vocabularyCards = [
  { id: 'v1', word: 'Abundant', pronunciation: '/əˈbʌn.dənt/', meaning: 'Existing in large quantities; more than enough', meaningRu: 'Обильный, изобильный', meaningKy: 'Кѳп, жетиштүү', example: 'The region has abundant natural resources.', level: 1 },
  { id: 'v2', word: 'Benevolent', pronunciation: '/bəˈnev.əl.ənt/', meaning: 'Well-meaning and kindly', meaningRu: 'Доброжелательный', meaningKy: 'Жакшы ниеттүү', example: 'A benevolent smile spread across her face.', level: 2 },
  { id: 'v3', word: 'Eloquent', pronunciation: '/ˈel.ə.kwənt/', meaning: 'Fluent or persuasive in speaking', meaningRu: 'Красноречивый', meaningKy: 'Кѳркѳм сүйлѳгѳн', example: 'She gave an eloquent speech.', level: 2 },
  { id: 'v4', word: 'Resilient', pronunciation: '/rɪˈzɪl.i.ənt/', meaning: 'Able to recover quickly from difficulties', meaningRu: 'Стойкий, устойчивый', meaningKy: 'Тез калыбына келүүчү', example: 'Children are remarkably resilient.', level: 3 },
  { id: 'v5', word: 'Ubiquitous', pronunciation: '/juːˈbɪk.wɪ.təs/', meaning: 'Present, appearing, or found everywhere', meaningRu: 'Вездесущий', meaningKy: 'Бардык жерде бар', example: 'Smartphones are ubiquitous these days.', level: 4 },
  { id: 'v6', word: 'Ephemeral', pronunciation: '/ɪˈfem.ər.əl/', meaning: 'Lasting for a very short time', meaningRu: 'Быстротечный', meaningKy: 'Кыска мѳѳнѳттүү', example: 'Fame can be ephemeral.', level: 4 },
  { id: 'v7', word: 'Meticulous', pronunciation: '/məˈtɪk.jə.ləs/', meaning: 'Showing great attention to detail', meaningRu: 'Тщательный', meaningKy: 'Ѳтѳ жоопкерчиликтүү', example: 'She is meticulous in her research.', level: 5 },
  { id: 'v8', word: 'Pragmatic', pronunciation: '/præɡˈmæt.ɪk/', meaning: 'Dealing with things sensibly and realistically', meaningRu: 'Прагматичный', meaningKy: 'Прагматикалык', example: 'We need a pragmatic approach.', level: 5 },
  { id: 'v9', word: 'Serendipity', pronunciation: '/ˌser.ənˈdɪp.ə.ti/', meaning: 'Finding pleasant things by chance', meaningRu: 'Счастливая случайность', meaningKy: 'Бактылуу кокустук', example: 'Finding this cafe was pure serendipity.', level: 6 },
  { id: 'v10', word: 'Perspicacious', pronunciation: '/ˌpɜː.spɪˈkeɪ.ʃəs/', meaning: 'Having a ready insight into things', meaningRu: 'Проницательный', meaningKy: 'Ѳткүр', example: 'A perspicacious judge of character.', level: 6 },
];

export const leaderboardData = [
  { rank: 1, name: 'Aida K.', avatar: '🏆', xp: 12500, streak: 45, level: 5, country: '🇰🇬' },
  { rank: 2, name: 'Dmitry S.', avatar: '🥈', xp: 11200, streak: 38, level: 5, country: '🇷🇺' },
  { rank: 3, name: 'Sarah M.', avatar: '🥉', xp: 10800, streak: 42, level: 5, country: '🇺🇸' },
  { rank: 4, name: 'Bek N.', avatar: '🌟', xp: 9500, streak: 30, level: 4, country: '🇰🇬' },
  { rank: 5, name: 'Elena V.', avatar: '⭐', xp: 8900, streak: 25, level: 4, country: '🇷🇺' },
  { rank: 6, name: 'James L.', avatar: '💫', xp: 8200, streak: 28, level: 4, country: '🇬🇧' },
  { rank: 7, name: 'Nuriza A.', avatar: '✨', xp: 7600, streak: 21, level: 3, country: '🇰🇬' },
  { rank: 8, name: 'Alex P.', avatar: '🎯', xp: 7100, streak: 19, level: 3, country: '🇷🇺' },
  { rank: 9, name: 'Maria G.', avatar: '🚀', xp: 6500, streak: 16, level: 3, country: '🇺🇸' },
  { rank: 10, name: 'Timur B.', avatar: '💎', xp: 5900, streak: 14, level: 3, country: '🇰🇬' },
];

export const achievementsList = [
  { id: 'first_lesson', icon: '🎯', nameEn: 'First Steps', nameRu: 'Первые шаги', nameKy: 'Биринчи кадамдар', descEn: 'Complete your first lesson', descRu: 'Завершите первый урок', descKy: 'Биринчи сабакты бүтүрүңүз', xpReward: 100 },
  { id: 'week_streak', icon: '🔥', nameEn: 'Week Warrior', nameRu: 'Воин недели', nameKy: 'Апта жоокери', descEn: 'Maintain a 7-day streak', descRu: 'Поддерживайте 7-дневную серию', descKy: '7 күндүк серияны сактаңыз', xpReward: 200 },
  { id: 'vocab_master', icon: '📚', nameEn: 'Vocabulary Master', nameRu: 'Мастер слов', nameKy: 'Сѳз чебери', descEn: 'Learn 100 new words', descRu: 'Выучите 100 новых слов', descKy: '100 жаңы сѳз үйрѳнүңүз', xpReward: 300 },
  { id: 'grammar_pro', icon: '📝', nameEn: 'Grammar Pro', nameRu: 'Грамматик', nameKy: 'Грамматика чебери', descEn: 'Complete all grammar lessons', descRu: 'Завершите все уроки грамматики', descKy: 'Бардык грамматика сабактарын бүтүрүңүз', xpReward: 500 },
  { id: 'top_student', icon: '🏆', nameEn: 'Top Student', nameRu: 'Лучший студент', nameKy: 'Мыкты студент', descEn: 'Reach Level 5', descRu: 'Достигните 5 уровня', descKy: '5-деңгээлге жетиңиз', xpReward: 400 },
  { id: 'ai_friend', icon: '🤖', nameEn: 'AI Best Friend', nameRu: 'Друг ИИ', nameKy: 'ИИ досу', descEn: 'Chat with AI 50 times', descRu: 'Пообщайтесь с ИИ 50 раз', descKy: 'ИИ менен 50 жолу сүйлѳшүңүз', xpReward: 150 },
];
